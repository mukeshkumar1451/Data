package Searching;

public class SearchInsertPositionoptimal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 1, 3, 5, 7 };
		int target = 8;

		int res = position(arr, target);
		System.out.println(res);

	}

	private static int position(int[] arr, int target) {
		// TODO Auto-generated method stub
		int left = 0;
		int right = arr.length - 1;
		int pos = arr.length;
		while (left <= right) {
			int mid = left + (right - left) / 2;
			if (arr[mid] == target) {
				return mid;
			}
			if (arr[mid] < target) {

				left = mid + 1;
			} else {
				pos = mid;
				right = mid - 1;
			}
		}
		return pos;
	}

}
