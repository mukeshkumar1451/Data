package Searching;

public class PeakIndexinaMountainArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 0, 3, 8, 9, 5, 2 };
		int res = peakIndexInMountainArray(arr);
		System.out.println(res);

	}

	public static int peakIndexInMountainArray(int[] arr) {

		for (int i = 1; i < arr.length; i++) {
			if (arr[i - 1] < arr[i] && arr[i] > arr[i + 1]) {
				return i;
			}
		}

		return -1;
	}

}
