package Searching;

public class SearchinRotatedSortedArray {
	// leetcode q.no 33

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 4, 5, 6, 7, 0, 1, 2 };
		int n = arr.length;
		int target = 0;
		int res = search(arr, target, n);
		System.out.println(res);

	}

	private static int search(int[] arr, int target, int n) {
		// TODO Auto-generated method stub
		int start = 0, end = n - 1;
		while (start <= end) {
			int mid = start + (end - start) / 2;
			// System.out.println(arr[mid]);
			if (arr[mid] == target) {

				return mid;
			}

			if (arr[start] <= arr[mid]) { // leftsorted
				if (arr[start] <= target && target <= arr[mid]) {
					end = mid - 1;
				} else {
					start = mid + 1;
				}

			} else {// right sorted
				if (arr[mid] <= target && target <= arr[end]) {
					start = mid + 1;
				} else {
					end = mid - 1;
				}

			}
		}

		return -1;
	}

}
