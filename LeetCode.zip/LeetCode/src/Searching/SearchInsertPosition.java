package Searching;

public class SearchInsertPosition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 1, 3, 5, 6 };
		int target = 7;

		int res = position(arr, target);
		System.out.println(res);

	}

	private static int position(int[] arr, int target) {
		// TODO Auto-generated method stub
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] >= target) {
				return i;
			}
		}
		return arr.length;
	}

}
