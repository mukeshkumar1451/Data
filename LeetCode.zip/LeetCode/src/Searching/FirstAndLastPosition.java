package Searching;

public class FirstAndLastPosition {
	// leetcode 34
	public static int[] searchRange(int[] nums, int target) {
		int first = findBound(nums, target, true);
		int last = findBound(nums, target, false);
		return new int[] { first, last };
	}

	private static int findBound(int[] nums, int target, boolean isFirst) {
		int left = 0, right = nums.length - 1;
		int result = -1;

		while (left <= right) {
			int mid = left + (right - left) / 2;

			if (nums[mid] < target) {
				left = mid + 1;
			} else if (nums[mid] > target) {
				right = mid - 1;
			} else {
				result = mid;
				if (isFirst) {
					right = mid - 1; // Search left half
				} else {
					left = mid + 1;
				}
			}
		}

		return result;
	}

	public static void main(String[] args) {
		int[] nums = { 5, 7, 7, 8, 8, 10 };
		int target = 8;
		int[] result = searchRange(nums, target);
		System.out.println("First and Last Position: [" + result[0] + ", " + result[1] + "]");
	}
}
