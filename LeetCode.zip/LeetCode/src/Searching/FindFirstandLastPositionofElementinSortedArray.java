package Searching;

import java.util.Arrays;

public class FindFirstandLastPositionofElementinSortedArray {

	public static void main(String[] args) {
		int[] arr = { 1 };
		int target = 1;
		int n = arr.length;

		System.out.println(Arrays.toString(PositionofElement(arr, target, n)));
	}

	private static int[] PositionofElement(int[] arr, int target, int n) {
		int[] sm = new int[2];
		sm[0] = sm[1] = -1;

		// Find first occurrence
		for (int i = 0; i < n; i++) {
			if (arr[i] == target) {
				sm[0] = i;
				break;
			}
		}

		// Find last occurrence
		for (int i = n - 1; i >= 0; i--) {
			if (arr[i] == target) {
				sm[1] = i;
				break;
			}
		}

		return sm;
	}
}
