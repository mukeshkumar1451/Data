package Searching;

public class PeakIndexinaMountainArrayOptimal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 0, 3, 8, 9, 5, 2 };
		int res = peakIndexInMountainArray(arr);
		System.out.println(res);

	}

	private static int peakIndexInMountainArray(int[] arr) {
		// TODO Auto-generated method stub
		int n = arr.length;
		int st = 1, end = n - 2;

		while (st <= end) {
			int mid = st + (end - st) / 2;
			if (arr[mid - 1] < arr[mid] && arr[mid] > arr[mid + 1]) {
				return mid;
			}
			if (arr[mid - 1] < arr[mid]) {
				st = mid + 1;
			} else {
				end = mid - 1;
			}
		}
		return -1;
	}

}
