package Searching;

public class SingleElementinaSortedArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 1, 1, 2, 2, 3, 4, 4, 8, 8 };
		int res = singleNonDuplicate(arr);
		System.out.println(res);

	}

	private static int singleNonDuplicate(int[] arr) {
		// TODO Auto-generated method stub
		int n = arr.length;
		for (int i = 1; i < n; i++) {
			if (arr[i - 1] != arr[i] && arr[i] != arr[i + 1]) {
				return i;
			}

		}
		return -1;
	}

}
