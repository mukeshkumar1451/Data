package LinkedList;

public class SwapPairs {
	Node head;

	class Node {
		int data;
		Node next;

		public Node(int data) {
			this.data = data;
			this.next = null;

		}

	}

	private void addLast(int data) {
		// TODO Auto-generated method stub
		Node newNode = new Node(data);
		if (head == null) {
			head = newNode;
			return;
		}

		Node currNode = head;
		while (currNode.next != null) {
			currNode = currNode.next;
		}
		currNode.next = newNode;
	}

	public Node swapPairs(Node head) {

		if (head == null || head.next == null) {
			return head;
		}

		Node first = head;
		Node sec = head.next;
		Node prev = null;
		while (first != null && sec != null) {
			Node third = sec.next;
			sec.next = first;
			first.next = third;
			if (prev != null) {
				prev.next = sec;
			} else {
				head = sec;
			}

			// update
			prev = first;
			first = third;
			if (third != null) {
				sec = third.next;
			} else {
				sec = null;
			}

		}
		return head;

	}

	private void printList() {
		// TODO Auto-generated method stub

		if (head == null) {
			System.out.println("List is empty");
			return;
		}

		Node currNode = head;
		while (currNode != null) {
			System.out.print(currNode.data + "->");
			currNode = currNode.next;
		}
		System.out.print("null");

	}

	public static void main(String[] args) {

		SwapPairs list = new SwapPairs();

		list.addLast(1);
		list.addLast(2);
		list.addLast(3);
		// list.addLast(4);
		list.printList();

		System.out.println();
		list.head = list.swapPairs(list.head);
		list.printList();

	}

}
