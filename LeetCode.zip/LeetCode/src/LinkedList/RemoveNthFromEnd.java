package LinkedList;

class ListNode {
	int val;
	ListNode next;

	ListNode(int x) {
		val = x;
	}
}

public class RemoveNthFromEnd {

	private ListNode removeNthFromEnd(ListNode head, int n) {
		// TODO Auto-generated method stub

		if (head.next == null) {
			return null;
		}
		int size = 0;
		ListNode current = head;
		while (current != null) {
			current = current.next;
			size++;
		}
		System.out.println(size);

		if (n == size) {
			return head.next;
		}

		int indexsearch = size - n;

		int i = 1;
		ListNode prev = head;
		while (i < indexsearch) {
			prev = prev.next;
			i++;
		}

		prev.next = prev.next.next;
		return head;

//		ListNode dummy = new ListNode(0);
//		System.out.println();
//		dummy.next = head;
//		ListNode first = dummy, second = dummy;
//
//		// Move first n+1 steps ahead
//		for (int i = 0; i <= n; i++) {
//			first = first.next;
//		}
//
//		// Move both pointers until first reaches the end
//		while (first != null) {
//			first = first.next;
//			second = second.next;
//		}
//
//		// Remove the node
//		second.next = second.next.next;
//
//		return dummy.next;
		// return null;

	}

	public static void printList(ListNode head) {
		while (head != null) {
			System.out.print(head.val + " ");
			head = head.next;
		}
		System.out.println();
	}

	public static ListNode createList(int[] values) {
		ListNode dummy = new ListNode(0);
		ListNode current = dummy;
		for (int val : values) {
			current.next = new ListNode(val);
			current = current.next;
		}
		return dummy.next;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] input = { 1, 2, 3, 4, 5 };
		int n = 2;

		ListNode head = createList(input);
		RemoveNthFromEnd solution = new RemoveNthFromEnd();
		ListNode result = solution.removeNthFromEnd(head, n);

		printList(result);

	}

}
