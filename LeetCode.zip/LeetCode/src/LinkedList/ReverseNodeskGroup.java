package LinkedList;

public class ReverseNodeskGroup {

	Node head;

	class Node {
		int data;
		Node next;

		public Node(int data) {
			this.data = data;
			this.next = null;

		}

	}

	private void addLast(int data) {
		// TODO Auto-generated method stub
		Node newNode = new Node(data);
		if (head == null) {
			head = newNode;
			return;
		}

		Node currNode = head;
		while (currNode.next != null) {
			currNode = currNode.next;
		}
		currNode.next = newNode;
	}

	private void printList() {
		// TODO Auto-generated method stub

		if (head == null) {
			System.out.println("List is empty");
			return;
		}

		Node currNode = head;
		while (currNode != null) {
			System.out.print(currNode.data + "->");
			currNode = currNode.next;
		}
		System.out.print("null");

	}

	public Node ReversekGroup(Node head, int k) {
		Node temp = head;
		int count = 0;
		// check if k nodes exist
		while (count < k) {
			if (temp == null) {
				return head;
			}
			temp = temp.next;
			count++;
		}
		// recursive call for rest linkedlist
		Node prev = ReversekGroup(temp, k);

		// reverse current group
		temp = head;
		count = 0;
		while (count < k) {
			Node next = temp.next;
			temp.next = prev;

			prev = temp;
			temp = next;
			count++;
		}

		return prev;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ReverseNodeskGroup list = new ReverseNodeskGroup();

		list.addLast(1);
		list.addLast(2);
		list.addLast(3);
		list.addLast(4);
		list.printList();

		System.out.println();

		list.head = list.ReversekGroup(list.head, 3);
		list.printList();

	}

}
