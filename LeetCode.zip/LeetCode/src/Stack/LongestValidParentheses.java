package Stack;

import java.util.Stack;

public class LongestValidParentheses {
	// leetcode q.no 32
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s = "())(())";
		System.out.println(longestValidParenthesesCheck(s));

	}

	private static int longestValidParenthesesCheck(String s) {
		// TODO Auto-generated method stub
		int maxlen = 0;

		for (int i = 0; i < s.length(); i++) {
			for (int j = i + 2; j <= s.length(); j += 2) {
				String sub = s.substring(i, j);
				if (isValid(sub)) {
					maxlen = Math.max(maxlen, sub.length());
				}
			}
		}
		return maxlen;
	}

	private static boolean isValid(String sub) {
		// TODO Auto-generated method stub
		Stack<Character> s = new Stack<Character>();
		for (char c : sub.toCharArray()) {
			if (c == '(') {
				s.push(c);
			} else {
				if (s.isEmpty()) {
					return false;
				}
				s.pop();
			}
		}
		return s.isEmpty();
	}

}
