package Stack;

import java.util.Stack;

public class LongestValidParenthesesOptimal {
	public static int longestValidParentheses(String s) {
		Stack<Integer> stack = new Stack<>();
		stack.push(-1); // base for valid substring
		int maxLen = 0;

		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);

			if (c == '(') {
				stack.push(i); // push index of '('
			} else {
				stack.pop(); // pop matching '('
				if (stack.isEmpty()) {
					stack.push(i); // reset base index
				} else {
					maxLen = Math.max(maxLen, i - stack.peek());
				}
			}
		}

		return maxLen;
	}

	public static void main(String[] args) {
		String s = ")()())()()(";

		System.out.println("Longest valid parentheses length: " + longestValidParentheses(s));
	}
}
