package ArrayList;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ListFourSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 0, 0, 0, 0 };
		int target = 0;
		ListFourSum s = new ListFourSum();
		List<List<Integer>> res = s.FourSum(arr, target);

		System.out.println(res);

	}

	public static List<List<Integer>> FourSum(int[] arr, int target) {
		List<List<Integer>> res = new ArrayList<List<Integer>>();
		int n = arr.length;
		Arrays.sort(arr);

		for (int i = 0; i < n - 3; i++) {
			if (i > 0 && arr[i] == arr[i - 1]) {
				continue;
			}
			for (int j = i + 1; j < n - 2; j++) {

				if (j < i + 1 && arr[j] == arr[j - 1]) {
					continue;
				}
				int p = j + 1;
				int q = n - 1;
				while (p < q) {
					long sum = (long) arr[i] + arr[j] + arr[p] + arr[q];
					if (sum < target) {
						p++;
					} else if (sum > target) {
						q--;
					} else {
						res.add(Arrays.asList(arr[i], arr[j], arr[p], arr[q]));
						p++;
						q--;

						while (p < q && arr[p] == arr[p - 1]) {
							p++;
						}
						while (p < q && arr[q] == arr[q + 1]) {
							q--;
						}

					}

				}

			}
		}

		return res;

	}

}
