package ArrayList;

import java.util.HashMap;
import java.util.Map;

public class ListTwoSum {
	public static void main(String[] args) {

		ListTwoSum s = new ListTwoSum();
		int[] arr = { 2, 5, 7, 11, 15 };
		int target = 9;
		int[] result = sum(arr, target);

		System.out.println(arr[result[0]] + " " + arr[result[1]]);

	}

	private static int[] sum(int[] arr, int target) {
		Map<Integer, Integer> m = new HashMap<>();
		for (int i = 0; i < arr.length; i++) {
			int second = target - arr[i];
			if (m.containsKey(second)) {
				return new int[] { m.get(second), i };
			}
			m.put(arr[i], i);
		}
		return new int[] {};
	}

}
