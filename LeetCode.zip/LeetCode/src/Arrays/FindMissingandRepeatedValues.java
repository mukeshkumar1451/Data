package Arrays;

import java.util.HashSet;
import java.util.Set;

public class FindMissingandRepeatedValues {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[][] grid = { { 9, 1, 7 }, { 8, 9, 2 }, { 3, 4, 6 } };

		int[] res = findMissingAndRepeatedValues(grid);
		System.out.println(res[0] + " " + res[1]);

	}

	private static int[] findMissingAndRepeatedValues(int[][] grid) {

		Set<Integer> s = new HashSet<Integer>();
		int n = grid.length;
		int a = 0, b = 0;
		int expsum = 0, actualsum = 0;

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				actualsum += grid[i][j];
				if (s.contains(grid[i][j])) {
					a = grid[i][j];
				}
				s.add(grid[i][j]);
			}
		}
		expsum = (n * n) * (n * n + 1) / 2;

		b = expsum + a - actualsum;

		return new int[] { a, b };

	}

}
