package Arrays;

public class BuyandSellStock {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 7, 1, 5, 3, 6, 4 };
		int res = maxProfit(arr);
		System.out.println(res);
	}

	public static int maxProfit(int[] arr) {

		int profit = 0;
		int bestbuy = arr[0];
		for (int i = 1; i < arr.length; i++) {
			if (arr[i] > bestbuy) {
				profit = Math.max(profit, arr[i] - bestbuy);
			}
			bestbuy = Math.min(arr[i], bestbuy);
		}
		return profit;

	}

}
