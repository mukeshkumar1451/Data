package Arrays;

public class FirstMissingPositiveoptimal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] nums = { 3, 4, -1, 1 };
		System.out.println(new FirstMissingPositiveoptimal().firstMissingPositive(nums));

	}

	private int firstMissingPositive(int[] arr) {
		int n = arr.length;
		for (int i = 0; i < n; i++) {
			while (arr[i] > 0 && arr[i] <= n && arr[arr[i] - 1] != arr[i]) {
				int temp = arr[i];
				arr[i] = arr[temp - 1];
				arr[temp - 1] = temp;

			}
		}

		for (int i = 0; i < n; i++) {
			if (arr[i] != i + 1) {
				return i + 1;
			}
		}

		return n + 1;
	}

}
