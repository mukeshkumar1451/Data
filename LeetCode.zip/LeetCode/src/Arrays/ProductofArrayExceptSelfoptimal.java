package Arrays;

import java.util.Arrays;

public class ProductofArrayExceptSelfoptimal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 1, 2, 3, 4 };

		int[] res = productExceptSelf(arr);

		System.out.println(Arrays.toString(res));

	}

	private static int[] productExceptSelf(int[] arr) {
		// TODO Auto-generated method stub
		int n = arr.length;
		int[] ans = new int[n];

		ans[0] = 1;

		for (int i = 1; i < n; i++) {
			ans[i] = ans[i - 1] * arr[i - 1];
		}
		int suffix = 1;
		for (int i = n - 2; i >= 0; i--) {
			suffix *= arr[i + 1];
			ans[i] *= suffix;
		}
		return ans;
	}

}
