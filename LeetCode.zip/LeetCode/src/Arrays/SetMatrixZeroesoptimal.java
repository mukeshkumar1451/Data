package Arrays;

import java.util.Arrays;

public class SetMatrixZeroesoptimal {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[][] matrix = { { 1, 1, 1 }, { 1, 0, 1 }, { 1, 1, 1 } };

		setZeroes(matrix);

		for (int[] interval : matrix) {
			System.out.println(Arrays.toString(interval));
		}

	}

	private static void setZeroes(int[][] arr) {
		// TODO Auto-generated method stub
		int rows = arr.length;
		int cols = arr[0].length;

		boolean firstrowzero = false;
		boolean firstcolzero = false;

		for (int j = 0; j < cols; j++) {
			if (arr[0][j] == 0) {
				firstrowzero = true;
				break;
			}
		}
		for (int i = 0; i < rows; i++) {
			if (arr[i][0] == 0) {
				firstcolzero = true;
				break;
			}
		}

		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				if (arr[i][j] == 0) {
					arr[i][0] = 0;
					arr[0][j] = 0;
				}
			}
		}

		for (int i = 1; i < rows; i++) {
			for (int j = 1; j < cols; j++) {
				if (arr[i][0] == 0 || arr[0][j] == 0) {
					arr[i][j] = 0;
				}
			}
		}

		if (firstrowzero) {
			for (int j = 0; j < cols; j++) {
				arr[0][j] = 0;
			}
		}

		if (firstcolzero) {
			for (int i = 0; i < rows; i++) {
				arr[i][0] = 0;
			}
		}

	}

}
