package Arrays;

public class SingleNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 4, 1, 2, 1, 2 };
		int res = singleNumbercheck(arr);
		System.out.println(res);

	}

	public static int singleNumbercheck(int[] arr) {

//		for (int i = 0; i < arr.length; i++) {
//			int count = 0;
//			for (int j = 0; j < arr.length; j++) {
//				if (arr[i] == arr[j]) {
//					count++;
//				}
//			}
//			if (count == 1) {
//				return arr[i];
//			}
//
//		}
//
//		return -1;
		int ans = 0;

		for (int val : arr) {
			ans = ans ^ val;
		}
		return ans;
	}

}
