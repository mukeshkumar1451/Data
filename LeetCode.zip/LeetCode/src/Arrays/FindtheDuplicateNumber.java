package Arrays;

public class FindtheDuplicateNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 1, 3, 4, 4, 2 };

		int res = findDuplicate(arr);
		System.out.println(res);

	}

	public static int findDuplicate(int[] arr) {
		int n = arr.length;
		int count = 0;
		for (int i = 0; i < n; i++) {
			if (arr[i] == arr[i + 1]) {
				count++;
			}
			if (count == 1) {
				return arr[i];
			}
		}

		return -1;
	}

}
