package Arrays;

import java.util.Arrays;

public class MediumOfTwoSortedArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums1 = { 1, 3 };
		int[] nums2 = { 2 };

		double res = Medium(nums1, nums2);
		System.out.println(res);

	}

	private static double Medium(int[] nums1, int[] nums2) {
		// TODO Auto-generated method stub

		int n = nums1.length;
		int m = nums2.length;
		int[] result = new int[n + m];
		int k = result.length;

		for (int i = 0; i < n; i++) {
			result[i] = nums1[i];

		}
		for (int i = 0; i < m; i++) {
			result[n + i] = nums2[i];
			// System.out.println(result[i]);
		}

		Arrays.sort(result);

		System.out.println();

		if (k % 2 == 0) {
			return (result[k / 2 - 1] + result[k / 2]) / 2.0;
		} else {
			return result[k / 2];
		}

	}

}
