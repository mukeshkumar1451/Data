package Arrays;

import java.util.Arrays;

public class SortColorsbrute {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 2, 0, 2, 1, 1, 0 };

		sortColors(arr);

		System.out.println(Arrays.toString(arr));

	}

	public static void sortColors(int[] arr) {

		int n = arr.length;
		int zero = 0, one = 0, two = 0;

		for (int i = 0; i < n; i++) {
			if (arr[i] == 0) {
				zero++;
			} else if (arr[i] == 1) {
				one++;
			} else {
				two++;
			}
		}

		int idx = 0;

		for (int i = 0; i < zero; i++) {
			arr[idx++] = 0;
		}
		for (int i = 0; i < one; i++) {
			arr[idx++] = 1;
		}
		for (int i = 0; i < two; i++) {
			arr[idx++] = 2;
		}

	}

}
