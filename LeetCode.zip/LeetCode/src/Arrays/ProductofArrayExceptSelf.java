package Arrays;

import java.util.Arrays;

public class ProductofArrayExceptSelf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 1, 2, 3, 4 };

		int[] res = productExceptSelf(arr);

		System.out.println(Arrays.toString(res));

	}

	public static int[] productExceptSelf(int[] arr) {
		int n = arr.length;
		int[] res = new int[n];

		for (int i = 0; i < n; i++) {
			int prod = 1;
			for (int j = 0; j < n; j++) {
				if (i != j) {
					prod *= arr[j];
				}
				res[i] = prod;
			}
		}
		return res;

	}

}
