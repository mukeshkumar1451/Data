package Arrays;

public class SubarraySumEqualsK {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 1, 1, 1 };
		int k = 2;

		int res = subarraySum(arr, k);
		System.out.println(res);

	}

	public static int subarraySum(int[] arr, int k) {
		int n = arr.length;
		int count = 0;
		for (int i = 0; i < n; i++) {
			int sum = 0;
			for (int j = i; j < n; j++) {
				sum += arr[j];
				if (sum == k) {
					count++;
				}
			}

		}

		return count;

	}

}
