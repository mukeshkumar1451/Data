package Arrays;

public class ReversePairs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 2147483647, 2147483647, 2147483647, 2147483647, 2147483647, 2147483647 };

		int res = reversePairs(arr);
		System.out.println(res);

	}

	public static int reversePairs(int[] arr) {

		int count = 0;

		for (int i = 0; i < arr.length; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				if ((long)arr[i] > 2L * arr[j]) {
					count++;
				}
			}
		}

		return count;

	}

}
