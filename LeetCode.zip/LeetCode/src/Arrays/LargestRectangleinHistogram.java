package Arrays;

public class LargestRectangleinHistogram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 2, 1, 5, 6, 2, 3 };
		int res = largestRectangleArea(arr);
		System.out.println(res);

	}

	public static int largestRectangleArea(int[] arr) {

		int maxarea = 0;
		for (int i = 0; i < arr.length; i++) {
			int minheight = arr[i];
			for (int j = i; j < arr.length; j++) {
				minheight = Math.min(minheight, arr[j]);
				int area = minheight * (j - i + 1);
				maxarea = Math.max(maxarea, area);
			}
		}

		return maxarea;

	}

}
