package Arrays;

public class MaximumSubarrayoptimal {
	public static void main(String[] args) {
		// TODO Auto-generated method stu}
		int[] arr = { -2, 1, -3, 4, -1, 2, 1, -5, 4 };
		int n = maxSubArray(arr);
		System.out.println(n);
	}

	private static int maxSubArray(int[] arr) {
		// TODO Auto-generated method stub
		int max = Integer.MIN_VALUE;
		int curr = 0;
		for (int i = 0; i < arr.length; i++) {
			curr += arr[i];
			max = Math.max(max, curr);

			if (curr < 0) {
				curr = 0;
			}
		}
		return max;
	}

}
