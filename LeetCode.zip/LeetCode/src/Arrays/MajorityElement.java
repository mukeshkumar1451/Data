package Arrays;

public class MajorityElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 2, 1, 1, 1, 1, 2, 2 };

		int n = arr.length;
		int res = major(arr, n);
		System.out.println(res);

	}

	private static int major(int[] arr, int n) {
		// TODO Auto-generated method stub

		for (int i = 0; i < n; i++) {
			int count = 1;
			for (int j = i + 1; j < n; j++) {
				if (arr[i] == arr[j]) {
					count++;
				}

				if (count > n / 2) {
					return arr[i];
				}
			}
		}

		return -1;
	}

}
