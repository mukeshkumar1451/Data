package Arrays;

import java.util.Arrays;

public class ThreeSumCloset {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { -1, 2, 1, -4 };
		int target = 1;

		int res = closet(arr, target);
		System.out.println(res);

	}

	private static int closet(int[] arr, int target) {
		// TODO Auto-generated method stub
		int n = arr.length;
		int diff = Integer.MAX_VALUE;
		int closet = 0;
		Arrays.sort(arr);
		for (int i = 0; i < n; i++) {

			int left = i + 1;
			int right = n - 1;

			while (left < right) {
				int sum = arr[i] + arr[left] + arr[right];
				if (sum == target) {
					return sum;
				}
				if (Math.abs(sum - target) < diff) {
					diff = Math.abs(sum - target);
					closet = sum;
				}
				if (target > sum) {
					left++;
				} else {
					right--;
				}
			}
		}
		return closet;
	}

}
