package Arrays;

public class JumpGame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 3, 2, 1, 0, 4 };

		boolean flag = canJump(arr);
		System.out.println(flag);

	}

	private static boolean canJump(int[] arr) {
		// TODO Auto-generated method stub
		int lastindex = arr.length - 1;

		for (int i = arr.length - 2; i >= 0; i--) {
			if (i + arr[i] >= lastindex) {
				lastindex = i;
			}
		}
		return lastindex == 0;
	}

}
