package Arrays;

import java.util.Arrays;

public class SlidingWindowMaximum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 1, 3, -1, -3, 5, 3, 6, 7 };
		int k = 3;

		int[] res = maxSlidingWindow(arr, k);

		System.out.println(Arrays.toString(res));

	}

	public static int[] maxSlidingWindow(int[] arr, int k) {

		int n = arr.length;
		int[] result = new int[n - k + 1];

		for (int i = 0; i <= n - k; i++) {
			int max = arr[i];
			for (int j = i + 1; j < i + k; j++) {
				max = Math.max(max, arr[j]);
			}
			result[i] = max;
		}

		return result;
	}

}
