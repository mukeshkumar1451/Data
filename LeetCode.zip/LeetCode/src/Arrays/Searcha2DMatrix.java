package Arrays;

public class Searcha2DMatrix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] matrix = { { 1, 3, 5, 7 }, { 10, 11, 16, 20 }, { 23, 30, 34, 60 } };
		int target = 4;
		boolean flag = searchMatrix(matrix, target);
		System.out.println(flag);

	}

	public static boolean searchMatrix(int[][] matrix, int target) {

		for (int[] row : matrix) {
			for (int num : row) {
				if (num == target) {
					return true;
				}
			}
		}

		return false;
	}

}
