package Arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GroupAnagramsoptimal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] strs = { "eat", "tea", "tan", "ate", "nat", "bat" };

		List<List<String>> res = groupAnagrams(strs);
		for (List<String> perm : res) {
			System.out.println(perm);
		}

	}

	private static List<List<String>> groupAnagrams(String[] strs) {
		// TODO Auto-generated method stub
		Map<String, List<String>> map = new HashMap<String, List<String>>();

		for (String s : strs) {
			char[] c = s.toCharArray();
			Arrays.sort(c);
			String key = new String(c);
			map.computeIfAbsent(key, k -> new ArrayList<>()).add(s);
		}
		return new ArrayList<List<String>>(map.values());
	}

}
