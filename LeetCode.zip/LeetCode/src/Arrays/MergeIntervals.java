package Arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MergeIntervals {

	public static void main(String[] args) {
		MergeIntervals mi = new MergeIntervals();
		int[][] input = { { 1, 3 }, { 2, 6 }, { 8, 10 }, { 15, 18 } };
		int[][] result = mi.merge(input);

		for (int[] interval : result) {
			System.out.println(Arrays.toString(interval));
		}
	}

	private int[][] merge(int[][] arr) {
		// TODO Auto-generated method stub
		if (arr.length <= 1) {
			return arr;
		}

		Arrays.sort(arr, (a, b) -> Integer.compare(a[0], b[0]));

		List<int[]> merged = new ArrayList<int[]>();
		int[] current = arr[0];
		merged.add(current);

		for (int[] interval : arr) {
			int currentend = current[1];
			int nextstart = interval[0];
			int nextend = interval[1];

			if (nextstart <= currentend) {
				current[1] = Math.max(currentend, nextend);
			} else {
				current = interval;
				merged.add(current);
			}
		}
		return merged.toArray(new int[merged.size()][]);
	}

}
