package Arrays;

public class LongestCommonPrefix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str[] = { "claw", "claf", "clar" };
		System.out.println(common(str));

	}

	private static String common(String[] str) {
		// TODO Auto-generated method stub

		String prefix = str[0];
		for (int i = 1; i < str.length; i++) {
			while (str[i].indexOf(prefix) != 0) {
				prefix = prefix.substring(0, prefix.length() - 1);

			}
			if (prefix.isEmpty()) {
				return "";
			}
		}
		return prefix;

		// bruteforce

//		Arrays.sort(str);
//		String str1 = str[0];
//		String str2 = str[str.length - 1];
//		int index = 0;
//		while (index < str1.length()) {
//			if (str1.charAt(index) == str2.charAt(index)) {
//				index++;
//			} else {
//				break;
//			}
//		}
//		return index == 0 ? "" : str1.substring(0, index);
	}

}
