package Arrays;

import java.util.Arrays;

public class SetMatrixZeroes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[][] matrix = { { 1, 1, 1 }, { 1, 0, 1 }, { 1, 1, 1 } };

		setZeroes(matrix);

		for (int[] interval : matrix) {
			System.out.println(Arrays.toString(interval));
		}

	}

	public static void setZeroes(int[][] arr) {
		int rows = arr.length;
		int cols = arr[0].length;
		// First pass: mark cells to be zeroed
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				if (arr[i][j] == 0) {
					// Mark row
					for (int k = 0; k < cols; k++) {
						if (arr[i][k] != 0) {
							arr[i][k] = -1;
						}
					}
					// Mark column
					for (int k = 0; k < rows; k++) {
						if (arr[k][j] != 0) {
							arr[k][j] = -1;
						}
					}
				}
			}
		}
		// Second pass: convert all -1 to 0
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				if (arr[i][j] == -1) {
					arr[i][j] = 0;
				}
			}
		}

	}

}
