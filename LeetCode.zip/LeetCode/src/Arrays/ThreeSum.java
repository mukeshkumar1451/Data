package Arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ThreeSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ThreeSum ts = new ThreeSum();
		int[] arr = { 2, -3, 0, -2, -5, -5, -4, 1, 2, -2, 2, 0, 2, -4, 5, 5, -10 };
		System.out.println(ts.threeSum(arr));

	}

	private List<List<Integer>> threeSum(int[] arr) {
		// TODO Auto-generated method stub

		List<List<Integer>> result = new ArrayList<>();
		int n = arr.length;

		Arrays.sort(arr);

		for (int i = 0; i < n - 2; i++) {
			if (i > 0 && arr[i] == arr[i - 1]) {
				continue;
			}

			int left = i + 1;
			int right = n - 1;
			while (left < right) {
				int sum = arr[i] + arr[left] + arr[right];

				if (sum == 0) {
					result.add(Arrays.asList(arr[i], arr[left], arr[right]));
					left++;
					right--;
//					while (left < right && arr[left] == arr[left - 1]) {
//						left++;
//					}
//					while (left < right && arr[right] == arr[right + 1]) {
//						right--;
//					}
				} else if (sum < 0) {
					left++;
				} else {
					right--;
				}

			}

		}

//		for (int i = 0; i < n; i++) {
//			for (int j = i + 1; j < n; j++) {
//				for (int k = j + 1; k < n; k++) {
//					if (arr[i] + arr[j] + arr[k] == 0) {
//						System.out.println(arr[i] + " " + arr[j] + " " + arr[k]);
//					} else {
//						break;
//					}
//				}
//			}
//		}

		return result;

	}

}
