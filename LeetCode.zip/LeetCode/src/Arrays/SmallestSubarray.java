package Arrays;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class SmallestSubarray {

	public static void main(String[] args) {
		// int[] arr = { 1, 0, 2, 1, 3 };
		int[] arr = { 1, 2 };
		int[] result = smallestSubarrayWithMaxOR(arr);

		for (int val : result) {
			System.out.println(val + " ");
		}
	}

	private static int[] smallestSubarrayWithMaxOR(int[] nums) {
		int n = nums.length;
		int[] result = new int[n];
		Map<Integer, Integer> orMap = new HashMap<>();

		for (int i = n - 1; i >= 0; i--) {
			Map<Integer, Integer> newMap = new HashMap<>();
			newMap.put(nums[i], i);

			for (Map.Entry<Integer, Integer> entry : orMap.entrySet()) {
				int newOR = entry.getKey() | nums[i];
				newMap.put(newOR, Math.min(newMap.getOrDefault(newOR, Integer.MAX_VALUE), entry.getValue()));
			}

			orMap = newMap;

			int maxOR = Collections.max(orMap.keySet());
			result[i] = orMap.get(maxOR) - i + 1;
		}

		return result;
	}
}

//	private static int[] smallestSubarrayWithMaxOR(int[] arr) {
//
//		int n = arr.length;
//		int[] result = new int[n];
//
//		for (int i = 0; i < n; i++) {
//			int maxOR = 0;
//			for (int j = i; j < n; j++) {
//				maxOR |= arr[j];
//			}
//			int currentOR = 0;
//			for (int j = i; j < n; j++) {
//				currentOR |= arr[j];
//				if (currentOR == maxOR) {
//
//					result[i] = j - i + 1;
//					break;
//				}
//			}
//
//		}
//		return result;
//
//	}
//}
