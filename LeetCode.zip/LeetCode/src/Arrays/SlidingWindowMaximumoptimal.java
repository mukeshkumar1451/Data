package Arrays;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;

public class SlidingWindowMaximumoptimal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 1, 3, -1, -3, 5, 3, 6, 7 };
		int k = 3;

		int[] res = maxSlidingWindow(arr, k);

		System.out.println(Arrays.toString(res));

	}

	private static int[] maxSlidingWindow(int[] arr, int k) {
		// TODO Auto-generated method stub
		int n = arr.length;
		int[] res = new int[n - k + 1];
		Deque<Integer> deque = new ArrayDeque<Integer>();

		for (int i = 0; i < n; i++) {

			while (!deque.isEmpty() && deque.peekFirst() <= i - k) {
				deque.pollFirst();
			}

			while (!deque.isEmpty() && arr[deque.peekLast()] < arr[i]) {
				deque.pollLast();
			}

			deque.offerLast(i);

			if (i >= k - 1) {
				res[i - k + 1] = arr[deque.peekFirst()];
			}
		}
		return res;
	}

}
