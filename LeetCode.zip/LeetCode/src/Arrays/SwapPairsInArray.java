package Arrays;

public class SwapPairsInArray {
	public static void main(String[] args) {
		int[] arr = { 1, 2, 3, 4, 5 };

		for (int i = 0; i < arr.length - 1; i += 2) {
			// Swap arr[i] and arr[i+1]
			int temp = arr[i];
			arr[i] = arr[i + 1];
			arr[i + 1] = temp;
		}

		// Print the swapped array
		for (int num : arr) {
			System.out.print(num + " ");
		}
	}
}
