package Arrays;

public class ReverseArraykGroup {

	public static void main(String[] args) {
		int[] arr = { 1, 2, 3, 4, 5, 6 };
		int k = 3;

		for (int i = 0; i < arr.length - k + 1; i += k) {
			// Swap arr[i] and arr[i + k - 1]
			int temp = arr[i];
			arr[i] = arr[i + k - 1];
			arr[i + k - 1] = temp;
		}

		// Print the result
		for (int num : arr) {
			System.out.print(num + " ");
		}
	}

}
