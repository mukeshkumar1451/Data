package Arrays;

import java.util.HashMap;

public class LongestSubstringWithoutRepeatingCharactersoptimal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "abcdabcbb";
		int res = lengthOfLongestSubstring(s);
		System.out.println(res);

	}

	private static int lengthOfLongestSubstring(String s) {
		// TODO Auto-generated method stub
		HashMap<Character, Integer> map = new HashMap<Character, Integer>();
		int j = 0, maxlen = 0;
		for (int i = 0; i < s.length(); i++) {
			char ch = s.charAt(i);

			if (map.containsKey(ch)) {
				j = Math.max(map.get(ch) + 1, j);
			}
			map.put(ch, i);

			maxlen = Math.max(maxlen, i - j + 1);
		}

		return maxlen;
	}

}
