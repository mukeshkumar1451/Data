package Arrays;

import java.util.Arrays;

public class SortColorsoptimal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 2, 0, 2, 1, 1, 0 };

		sortColors(arr);

		System.out.println(Arrays.toString(arr));

	}

	private static void sortColors(int[] arr) {
		// TODO Auto-generated method stub
		int n = arr.length;

		int mid = 0, high = n - 1, low = 0;

		while (mid <= high) {
			if (arr[mid] == 0) {
				swap(arr, low, mid);
				mid++;
				low++;
			} else if (arr[mid] == 1) {
				mid++;
			} else {
				swap(arr, high, mid);
				high--;
			}
		}

	}

	private static void swap(int[] arr, int i, int j) {
		// TODO Auto-generated method stub
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;

	}

}
