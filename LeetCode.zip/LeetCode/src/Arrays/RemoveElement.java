package Arrays;

public class RemoveElement {
	// leetcode q.no27

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 1, 1, 2, 9, 7 };

		int n = arr.length;
		int k = 1;

		int dep = Remove(arr, n, k);
		System.out.println(dep);

	}

	private static int Remove(int[] arr, int n, int k) {
		// TODO Auto-generated method stub
		int res = 0;
		for (int i = 0; i < n; i++) {
			if (arr[i] != k) {
				arr[res] = arr[i];
				res++;
			}
		}
		return res;
	}

}
