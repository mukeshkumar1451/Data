package Arrays;

import java.util.HashSet;
import java.util.Set;

public class FirstMissingPositiveBruteForce {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] nums = { 3, 4, -1, 1 };
		System.out.println(new FirstMissingPositiveBruteForce().firstMissingPositive(nums));

	}

	private int firstMissingPositive(int[] nums) {
		// TODO Auto-generated method stub
		Set<Integer> s = new HashSet<Integer>();
		for (int num : nums) {
			s.add(num);
		}

		for (int i = 1; i < nums.length; i++) {
			if (!s.contains(i)) {
				return i;
			}
		}
		return -1;
	}

}
