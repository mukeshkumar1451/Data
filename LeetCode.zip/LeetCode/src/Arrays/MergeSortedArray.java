package Arrays;

import java.util.Arrays;

public class MergeSortedArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr1 = { 1, 2, 3, 0, 0, 0 };
		int m = 3;
		int[] arr2 = { 2, 5, 6 };
		int n = 3;
		merge(arr1, m, arr2, n);
		System.out.println(Arrays.toString(arr1));

	}

	public static void merge(int[] arr1, int m, int[] arr2, int n) {

		int k = m + n - 1;
		int i = m - 1;
		int j = n - 1;

		while (i >= 0 && j >= 0) {
			if (arr1[i] > arr2[j]) {
				arr1[k] = arr1[i];
				k--;
				i--;
			} else {
				arr1[k] = arr2[j];
				k--;
				j--;
			}
		}

		while (j >= 0) {
			arr1[k] = arr2[j];
			k--;
			j--;
		}

	}

}
