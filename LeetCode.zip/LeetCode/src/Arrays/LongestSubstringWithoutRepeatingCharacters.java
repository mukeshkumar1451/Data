package Arrays;

import java.util.HashSet;
import java.util.Set;

public class LongestSubstringWithoutRepeatingCharacters {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s = "abcdabcbb";
		int res = lengthOfLongestSubstring(s);
		System.out.println(res);

	}

	public static int lengthOfLongestSubstring(String s) {

		int maxlen = 0;
		for (int i = 0; i < s.length(); i++) {
			Set<Character> seen = new HashSet<Character>();
			for (int j = i; j < s.length(); j++) {
				char ch = s.charAt(j);
				if (seen.contains(ch)) {
					break;
				}
				seen.add(ch);

				maxlen = Math.max(maxlen, j - i + 1);
			}
		}

		return maxlen;

	}

}
