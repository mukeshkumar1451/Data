package Arrays;

public class MaximumSubarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stu}
		int[] arr = { -2, 1, -3, 4, -1, 2, 1, -5, 4 };
		int n = maxSubArray(arr);
		System.out.println(n);
	}

	private static int maxSubArray(int[] arr) {

		int max = Integer.MIN_VALUE;

		for (int i = 0; i < arr.length; i++) {
			int curr = 0;
			for (int j = i; j < arr.length; j++) {
				curr += arr[j];
				max = Math.max(max, curr);

			}
		}

		return max;

	}
}
