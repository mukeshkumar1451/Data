package Arrays;

public class TwoSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 2, 7, 11, 15 };
		int target = 9;
		int k = sum(arr, target);
		for (int val : arr) {
			System.out.println(val + " ");
		}

	}

	private static int sum(int[] arr, int target) {
		// TODO Auto-generated method stub
		int n = arr.length;

		for (int i = 0; i < n; i++) {
			for (int j = i; j < n; j++) {
				if (arr[i] + arr[j] == target) {
					return arr[i];
				}
			}

		}
		return -1;

	}

}
