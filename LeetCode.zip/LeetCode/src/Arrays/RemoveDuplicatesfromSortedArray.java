package Arrays;

//leetcode q.no=26

public class RemoveDuplicatesfromSortedArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 10, 12, 12, 19 };

		int n = arr.length;

		int dep = duplicate(arr, n);
		System.out.println(dep);
		for (int i = 0; i < dep; i++) {
			System.out.println(arr[i]);
		}

	}

	private static int duplicate(int[] arr, int n) {
		// TODO Auto-generated method stub
		int res = 1;
		for (int i = 1; i < n; i++) {
			if (arr[i] != arr[res - 1]) {
				arr[res] = arr[i];
				res++;
			}

		}
		return res;

	}

}
