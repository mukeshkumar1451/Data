package Arrays;

import java.util.HashMap;

public class SubarraySumEqualsKoptimal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 1, 1, 1 };
		int k = 2;

		int res = subarraySum(arr, k);
		System.out.println(res);

	}

	private static int subarraySum(int[] arr, int k) {
		// TODO Auto-generated method stub
		int count = 0, sum = 0;

		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		map.put(0, 1);

		for (int i : arr) {
			sum += i;
			if (map.containsKey(sum - k)) {
				count += map.get(sum - k);
			}
			map.put(sum, map.getOrDefault(sum, 0) + 1);
		}
		return count;
	}

}
