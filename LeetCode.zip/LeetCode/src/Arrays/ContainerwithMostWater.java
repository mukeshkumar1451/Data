package Arrays;

public class ContainerwithMostWater {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 1, 8, 6, 2, 5, 4, 8, 3, 7 };
		int n = arr.length;
		int result = water(arr, n);
		System.out.println(result);
	}

	private static int water(int[] arr, int n) {
		// TODO Auto-generated method stub
		int maxwater = 0;

		int left = 0, right = n - 1;
		while (left < right) {
			int width = right - left;
			int height = Math.min(arr[left], arr[right]);
			int currentWater = width * height;
			maxwater = Math.max(maxwater, currentWater);

			if (arr[left] < arr[right]) {
				left++;
			} else {
				right--;
			}

		}
		return maxwater;
	}
}

// Brute force
//		for (int i = 0; i < n; i++) {
//			for (int j = i + 1; j < n; j++) {
//				int width = j - i;
//				int height = Math.min(arr[i], arr[j]);
//				int area = width * height;
//				maxwater = Math.max(area, maxwater);
//			}
//		}
//		return maxwater;
//	}

//}
