package Arrays;

public class Searcha2DMatrixoptimal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// int[][] matrix = { { 1, 3, 5, 7 }, { 10, 11, 16, 20 }, { 23, 30, 34, 60 } };
		int[][] matrix = { { 1 }, { 3 } };
		int target = 2;
		boolean flag = searchMatrix(matrix, target);
		System.out.println(flag);

	}

	private static boolean searchMatrix(int[][] matrix, int target) {
		// TODO Auto-generated method stub
		int m = matrix.length;
		int n = matrix[0].length;
		int left = 0, right = m * n - 1;

		while (left <= right) {
			int mid = left + (right - left) / 2;
			int row = mid / n;
			int col = mid % n;
			int midvalue = matrix[row][col];
			if (midvalue == target) {
				return true;
			} else if (midvalue < target) {
				left = mid + 1;
			} else {
				right = mid - 1;
			}
		}
		return false;
	}

}
