package Arrays;

import java.util.Stack;

public class LargestRectangleinHistogramoptimal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 2, 1, 5, 6, 2, 3 };
		int res = largestRectangleArea(arr);
		System.out.println(res);

	}

	private static int largestRectangleArea(int[] heights) {
		// TODO Auto-generated method stub

		Stack<Integer> stack = new Stack<>();
		int maxArea = 0;
		int n = heights.length;

		for (int i = 0; i <= n; i++) {
			int currentHeight = (i == n) ? 0 : heights[i];

			while (!stack.isEmpty() && currentHeight < heights[stack.peek()]) {
				int height = heights[stack.pop()];
				int width = stack.isEmpty() ? i : i - stack.peek() - 1;
				maxArea = Math.max(maxArea, height * width);
			}

			stack.push(i);
		}

		return maxArea;
	}

}
