package Normal;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Permutationduplicate {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 1, 1, 2 };
		int n = arr.length;
		List<List<Integer>> res = permute(arr);
		for (List<Integer> perm : res) {
			System.out.println(perm);
		}

	}

	private static List<List<Integer>> permute(int[] arr) {
		List<List<Integer>> res = new ArrayList<List<Integer>>();
		Set<String> s = new HashSet<>();
		getpermutation(arr, 0, s, res);
		return res;
	}

	private static void getpermutation(int[] arr, int start, Set<String> s, List<List<Integer>> res) {

		if (start == arr.length) {
			List<Integer> permutation = new ArrayList<>();
			for (int num : arr) {
				permutation.add(num);
			}
			String key = permutation.toString();
			if (!s.contains(key)) {
				res.add(permutation);
				s.add(key);
			}

			return;
		}
		for (int i = start; i < arr.length; i++) {
			swap(arr, start, i);
			getpermutation(arr, start + 1, s, res);
			swap(arr, start, i);
		}
	}

	private static void swap(int[] arr, int start, int i) {
		// TODO Auto-generated method stub

		int temp = arr[start];
		arr[start] = arr[i];
		arr[i] = temp;

	}

}
