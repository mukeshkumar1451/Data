package Normal;

import java.util.ArrayList;
import java.util.List;

public class Permutation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 1, 1, 2 };
		int n = arr.length;
		List<List<Integer>> res = permute(arr);
		for (List<Integer> perm : res) {
			System.out.println(perm);
		}

	}

	private static List<List<Integer>> permute(int[] arr) {
		List<List<Integer>> res = new ArrayList<List<Integer>>();
		getpermutation(arr, 0, res);
		return res;
	}

	private static void getpermutation(int[] arr, int start, List<List<Integer>> res) {

		if (start == arr.length) {
			List<Integer> permutation = new ArrayList<>();
			for (int num : arr) {
				permutation.add(num);
			}
			res.add(permutation);
			return;
		}
		for (int i = start; i < arr.length; i++) {
			swap(arr, start, i);
			getpermutation(arr, start + 1, res);
			swap(arr, start, i);
		}
	}

	private static void swap(int[] arr, int start, int i) {
		// TODO Auto-generated method stub

		int temp = arr[start];
		arr[start] = arr[i];
		arr[i] = temp;

	}

}
