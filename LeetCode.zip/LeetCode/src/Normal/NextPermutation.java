package Normal;

import java.util.Arrays;

public class NextPermutation {

	// leetcode q.no31

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 1, 2, 5, 4, 3 };
		int n = arr.length;

		permutation(arr, n);
		System.out.println(Arrays.toString(arr));

	}

	private static void permutation(int[] arr, int n) {
		// TODO Auto-generated method stub

		int piv = -1;
		for (int i = n - 2; i >= 0; i--) {
			if (arr[i] < arr[i + 1]) {
				piv = i;
				break;
			}
		}

		if (piv == -1) {
			reverse(arr, 0, n - 1);
			return;

		}
		for (int i = n - 1; i > piv; i--) {
			if (arr[i] > arr[piv]) {
				swap(arr, i, piv);
				break;
			}
		}

		int i = piv + 1, j = n - 1;
		while (i < j) {
			swap(arr, i, j);
			i++;
			j--;

		}

	}

	private static void reverse(int[] arr, int i, int j) {
		// TODO Auto-generated method stub
		while (i < j) {
			swap(arr, i, j);
			i++;
			j--;
		}

	}

	private static void swap(int[] arr, int i, int j) {
		// TODO Auto-generated method stub
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;

	}

}
