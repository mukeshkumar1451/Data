package Normal;

public class DivideTwoIntegers {
	// leetcode q.no29
	public static int divide(int dividend, int divisor) {
		// Handle edge cases
		if (dividend == Integer.MIN_VALUE && divisor == -1) {
			return Integer.MAX_VALUE; // Overflow case
		}

		// Determine sign of result
		boolean negative = (dividend < 0) ^ (divisor < 0);

		// Convert to long and take absolute values
		long lDividend = Math.abs((long) dividend);
		long lDivisor = Math.abs((long) divisor);

		int result = 0;

		while (lDividend >= lDivisor) {
			long temp = lDivisor, multiple = 1;
			while (lDividend >= (temp << 1)) {
				temp <<= 1;
				multiple <<= 1;
			}
			lDividend -= temp;
			result += multiple;
		}

		return negative ? -result : result;
	}

	public static void main(String[] args) {
		int dividend = -2147483648;
		int divisor = -1;
		System.out.println("Result: " + divide(dividend, divisor));
	}

}
