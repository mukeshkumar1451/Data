package String;

public class FindtheIndexoftheFirstOccurrenceinaString {
	// leetcode q.no28
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String haystack = "sadbutsad";
		String needle = "sadk";
		int i = strStr(haystack, needle);
		System.out.println(i);

	}

	public static int strStr(String haystack, String needle) {

		for (int i = 0; i < haystack.length() - needle.length() + 1; i++) {
			if (haystack.charAt(i) == needle.charAt(0)) {
				if (haystack.substring(i, needle.length() + i).equals(needle)) {
					return i;
				}
			}
		}
		return -1;

		// oneline code
		// return haystack.indexOf(needle);
	}

}
