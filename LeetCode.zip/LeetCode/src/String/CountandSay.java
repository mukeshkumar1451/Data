package String;

public class CountandSay {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 6;

		// String s=;
		System.out.println(count(n));

	}

	private static String count(int n) {
		// TODO Auto-generated method stub
		String result = "1";
		for (int i = 1; i < n; i++) {
			StringBuilder s = new StringBuilder();
			int count = 1;
			for (int j = 1; j < result.length(); j++) {
				if (result.charAt(j) == result.charAt(j - 1)) {
					count++;
				} else {
					s.append(count).append(result.charAt(j - 1));
					count = 1;
				}

			}
			s.append(count).append(result.charAt(result.length() - 1));
			result = s.toString();
		}
		return result;
	}

}
