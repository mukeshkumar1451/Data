package String;

import java.util.Stack;

public class ValidParentheses {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "[}"; // Example input
		boolean flag = ValidBrackets(str);
		System.out.println(flag);
	}

	private static boolean ValidBrackets(String str) {
		// TODO Auto-generated method stub
		Stack<Character> s = new Stack<Character>();

		for (char ch : str.toCharArray()) {
			if (ch == '(' || ch == '{' || ch == '[') {
				s.push(ch);
			} else {
				if (s.isEmpty()) {
					return false;
				}

				char top = s.pop();
				if ((ch == ')' && top != '(') || (ch == '}' && top != '{') || (ch == ']' && top != '[')) {
					return false;
				}

			}

		}
		return s.isEmpty();
	}

}
