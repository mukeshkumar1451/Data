package String;

public class ValidPalindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s = "A man, a plan, a canal: Panama";

		System.out.println(isPalindrome(s));

	}

	public static boolean isPalindrome(String s) {

		int n = s.length();
		int st = 0, end = n - 1;

		while (st < end) {
			while (st < end && !Character.isLetterOrDigit(s.charAt(st))) {
				st++;
			}
			while (st < end && !Character.isLetterOrDigit(s.charAt(end))) {
				end--;
			}

			if (Character.toLowerCase(s.charAt(st)) != Character.toLowerCase(s.charAt(end))) {
				return false;
			}
			st++;
			end--;
		}
		return true;
	}

}
