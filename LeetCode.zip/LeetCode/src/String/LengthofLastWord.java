package String;

public class LengthofLastWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "Hello Worlds";
		int res = lengthOfLastWord(s);
		System.out.println(res);

	}

	private static int lengthOfLastWord(String s) {
		// TODO Auto-generated method stub
		s = s.trim();
		int length = 0;

		for (int i = s.length() - 1; i >= 0; i--) {
			if (s.charAt(i) == ' ') {
				break;
			}
			length++;

		}

		return length;
	}

}
