package RECURSIONandBACKTRACKING;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CombinationSum1Optimal {

	private void backtrack(int[] candidates, int target, int start, List<Integer> current, List<List<Integer>> result) {
		if (target == 0) {
			result.add(new ArrayList<>(current));
			return;
		}

		for (int i = start; i < candidates.length; i++) {
			if (candidates[i] > target) {
				break; // Early stopping
			}
			current.add(candidates[i]);
			backtrack(candidates, target - candidates[i], i, current, result); // Reuse same element
			current.remove(current.size() - 1);
		}
	}

	public List<List<Integer>> combinationSum(int[] candidates, int target) {
		List<List<Integer>> result = new ArrayList<>();
		Arrays.sort(candidates); // Optional: helps with early stopping
		List<Integer> current = new ArrayList<>();
		backtrack(candidates, target, 0, current, result);
		return result;
	}

	public static void main(String[] args) {
		CombinationSum1Optimal cs = new CombinationSum1Optimal();
		int[] candidates = { 10, 1, 2, 7, 6, 1, 5 };
		int target = 8;
		System.out.println(cs.combinationSum(candidates, target));
	}

}
