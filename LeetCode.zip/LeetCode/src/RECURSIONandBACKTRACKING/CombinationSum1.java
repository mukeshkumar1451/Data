package RECURSIONandBACKTRACKING;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CombinationSum1 {

	Set<Integer> s = new HashSet<Integer>();

	public static void main(String[] args) {
		CombinationSum1 cs = new CombinationSum1();
		int[] candidates = { 10, 1, 2, 7, 6, 1, 5 };
		int target = 8;
		System.out.println(cs.combinationSum(candidates, target));
	}

	private void backtrack(int[] candidates, int target, int start, List<Integer> current, List<List<Integer>> result) {
		if (target == 0) {
			result.add(new ArrayList<>(current));
			return;
		}

		for (int i = start; i < candidates.length; i++) {

			if (i > start && candidates[i] == candidates[i - 1]) {
				continue;
			}

			if (candidates[i] > target) {
				break; // Early stopping
			}
			current.add(candidates[i]);
			backtrack(candidates, target - candidates[i], i + 1, current, result); // Reuse same element
			current.remove(current.size() - 1);
		}
	}

	public List<List<Integer>> combinationSum(int[] candidates, int target) {
		List<List<Integer>> result = new ArrayList<>();
		Arrays.sort(candidates); // Optional: helps with early stopping
		List<Integer> current = new ArrayList<>();
		backtrack(candidates, target, 0, current, result);
		return result;
	}

}
