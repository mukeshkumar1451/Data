package Sudoku;

import java.util.HashSet;

public class ValidSudoku {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char[][] board = { { '5', '3', '.', '.', '7', '.', '.', '.', '.' },
				{ '6', '.', '.', '1', '9', '5', '.', '.', '.' }, { '.', '9', '8', '.', '.', '.', '.', '6', '.' },
				{ '8', '.', '.', '.', '6', '.', '.', '.', '3' }, { '4', '.', '.', '8', '.', '3', '.', '.', '1' },
				{ '7', '.', '.', '.', '2', '.', '.', '.', '6' }, { '.', '6', '.', '.', '.', '.', '2', '8', '.' },
				{ '.', '.', '.', '4', '1', '9', '.', '.', '5' }, { '.', '.', '.', '.', '8', '.', '.', '7', '9' } };

		ValidSudoku s = new ValidSudoku();

		boolean flag = s.isvaildSudoku(board);
		System.out.println(flag);

	}

	boolean isvaildSudoku(char[][] board) {
		// TODO Auto-generated method stub
		HashSet<String> set = new HashSet<String>();

		for (int i = 0; i < 9; i++) {
			for (int j = 0; j < 9; j++) {
				char number = board[i][j];
				if (number != '.') {
					if (!set.add(number + " row " + i) || !set.add(number + " col " + j)
							|| !set.add(number + " box " + (i / 3) + "-" + (j / 3))) {
						return false;
					}
				}
			}
		}

		return true;
	}

}
