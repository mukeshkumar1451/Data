package Stack;

import java.util.ArrayDeque;
import java.util.Deque;

public class BalancedParentheis {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "({]})";
		int n = str.length();
		boolean flag = balance(str, n);
		System.out.println(flag);

	}

	private static boolean balance(String str, int n) {
		// TODO Auto-generated method stub
		Deque<Character> s = new ArrayDeque<Character>();

		for (int i = 0; i < n; i++) {
			char x = str.charAt(i);
			if (x == '(' || x == '{' || x == '[') {
				s.push(x);
			} else {
				if (s.isEmpty() == true) {
					return false;
				} else if (Matching(s.peek(), x) == false) {
					return false;
				} else {
					s.pop();
				}

			}

		}
		return (s.isEmpty() == true);
	}

	private static boolean Matching(Character a, char b) {
		// TODO Auto-generated method stub

		return ((a == '(' && b == ')') || (a == '{' && b == '}') || (a == '[' && b == ']'));

	}

}
