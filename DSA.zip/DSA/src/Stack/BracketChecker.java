package Stack;

import java.util.Stack;

public class BracketChecker {

	public static void main(String[] args) {
		String expr = "{[}"; // Example input
		checkBrackets(expr);
	}

	public static void checkBrackets(String expr) {
		Stack<Character> stack = new Stack<>();

		for (char ch : expr.toCharArray()) {
			if (ch == '(' || ch == '{' || ch == '[') {
				stack.push(ch);
			} else if (ch == ')' || ch == '}' || ch == ']') {
				if (stack.isEmpty()) {
					System.out.println("Extra closing bracket: " + ch);
					return;
				}

				char top = stack.pop();
				if (!isMatching(top, ch)) {
					System.out.println("Mismatched brackets: " + top + " and " + ch);
					return;
				}
			}
		}

		// Check for any unmatched opening brackets
		while (!stack.isEmpty()) {
			char missing = stack.pop();
			System.out.println("Missing closing bracket for: " + missing + " → " + getClosing(missing));
		}

		if (stack.isEmpty()) {
			System.out.println("All brackets are balanced.");
		}
	}

	private static boolean isMatching(char open, char close) {
		return (open == '(' && close == ')') || (open == '{' && close == '}') || (open == '[' && close == ']');
	}

	private static char getClosing(char open) {
		switch (open) {
		case '(':
			return ')';
		case '{':
			return '}';
		case '[':
			return ']';
		default:
			return '?';
		}
	}
}
