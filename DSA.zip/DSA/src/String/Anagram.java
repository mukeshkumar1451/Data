package String;

import java.util.Arrays;

public class Anagram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s1 = "slient";
		String s2 = "listen";
		boolean flag = same(s1, s2);
		System.out.println(flag);

	}

	private static boolean same(String s1, String s2) {
		// TODO Auto-generated method stub
		if (s1.length() != s2.length()) {
			return false;
		}
		char a1[] = s1.toCharArray();
		Arrays.sort(a1);
		s1 = new String(a1);

		char a2[] = s2.toCharArray();
		Arrays.sort(a2);
		s2 = new String(a2);

		return s1.equals(s2);
	}

}
