package String;

public class LongestSubStringwithDistinctchar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "abcdabc";
		int n = str.length();
		int res = longsub(str, n);
		System.out.println(res);

	}

	private static int longsub(String str, int n) {
		// TODO Auto-generated method stub
		int res = 0;
		for (int i = 0; i < n; i++) {
			boolean Visted[] = new boolean[256];
			for (int j = i; j < n; j++) {
				if (Visted[str.charAt(j)] == true) {
					break;
				} else {
					res = Math.max(res, j - i + 1);
					Visted[str.charAt(j)] = true;
				}
			}
		}
		return res;
	}

}
