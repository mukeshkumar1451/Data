package String;

public class PatterSearching {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "aaaaa";
		String pat = "aaa";
		patsearch(s1, pat);

	}

	private static void patsearch(String s1, String pat) {
		// TODO Auto-generated method stub
		int n = s1.length();
		int m = pat.length();
		for (int i = 0; i <= n - m; i++) {
			int j;
			for (j = 0; j < m; j++) {
				if (pat.charAt(j) != s1.charAt(i + j)) {
					break;
				}
			}
			if (j == m) {
				System.out.println(i + " ");
			}
		}

	}

}
