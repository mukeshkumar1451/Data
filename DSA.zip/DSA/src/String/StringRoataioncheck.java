package String;

public class StringRoataioncheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s1 = "ABCD";
		String s2 = "CDAB";
		boolean flag = Rotaion(s1, s2);
		System.out.println(flag);

	}

	private static boolean Rotaion(String s1, String s2) {
		// TODO Auto-generated method stub
		if (s1.length() != s2.length()) {
			return false;
		}
		return ((s1 + s1).indexOf(s2) > 0);
	}

}
