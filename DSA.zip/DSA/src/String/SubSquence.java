package String;

public class SubSquence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] s1 = { "ABCDEF" };
		String[] s2 = { "ADT" };

		int n = s1.length;
		int m = s2.length;

		boolean res = subsq(s1, s2, m, n);
		System.out.println(res);

	}

	private static boolean subsq(String[] s1, String[] s2, int m, int n) {
		// TODO Auto-generated method stub

		if (m == 0) {
			return true;
		}
		if (n == 0) {
			return false;
		}
		if (s1[n - 1] == s2[m - 1]) {
			return subsq(s1, s2, n - 1, m - 1);
		}
		return subsq(s1, s2, n - 1, m);
	}

}
