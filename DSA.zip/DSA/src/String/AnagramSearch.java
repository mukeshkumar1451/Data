package String;

public class AnagramSearch {
	static final int CHAR = 256;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s1 = "geeksforgeeks";
		String s2 = "t";
		boolean flag = Search(s1, s2);
		System.out.println(flag);

	}

	private static boolean Search(String s1, String s2) {
		// TODO Auto-generated method stub
		int[] CT = new int[CHAR];
		int[] CP = new int[CHAR];

		for (int i = 0; i < s2.length(); i++) {
			CT[s1.charAt(i)]++;
			CP[s2.charAt(i)]++;
		}
		for (int i = s2.length(); i < s1.length(); i++) {
			if (areEqual(CT, CP)) {
				return true;
			}

			CT[s1.charAt(i)]++;
			CT[s1.charAt(i - s2.length())]--;
		}

		return false;
	}

	private static boolean areEqual(int[] a, int[] b) {
		for (int i = 0; i < CHAR; i++) {
			if (a[i] != b[i]) {
				return false;
			}
		}
		return true;
	}

}
