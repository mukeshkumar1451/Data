package String;

public class Plaindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "ABBA";
		boolean flag = isplain(str);
		System.out.println(flag);

	}

	private static boolean isplain(String str) {
		// TODO Auto-generated method stub
		int i = 0;
		int j = str.length() - 1;
		while (i < j) {
			if (str.charAt(i) != str.charAt(j)) {
				return false;

			}
			i++;
			j--;

		}
		return true;
	}

}
