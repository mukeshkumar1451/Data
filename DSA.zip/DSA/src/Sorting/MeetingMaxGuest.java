package Sorting;

import java.util.Arrays;

public class MeetingMaxGuest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 900, 600, 700 };
		int[] dep = { 1000, 800, 730 };
		int n = arr.length;

		int res = maxguest(arr, dep, n);
		System.out.println(res);

	}

	private static int maxguest(int[] arr, int[] dep, int n) {
		// TODO Auto-generated method stub
		Arrays.sort(arr);
		Arrays.sort(dep);
		int i = 1, j = 0, res = 1, count = 1;

		while (i < n && j < n) {
			if (arr[i] <= dep[j]) {
				count++;
				i++;
			} else {
				count--;
				j++;
			}
			res = Math.max(res, count);

		}
		return res;
	}

}
