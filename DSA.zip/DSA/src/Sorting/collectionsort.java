package Sorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class collectionsort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> li = new ArrayList<Integer>();
		li.add(6);
		li.add(2);
		li.add(8);

		System.out.println(li);

		Collections.sort(li);
		System.out.println(li);
		Collections.sort(li, Collections.reverseOrder());

		System.out.println(li);

	}

}
