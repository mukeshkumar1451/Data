package Sorting;

public class MergeSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a = { 2, 4, 7 };
		int[] b = { 1, 5, 9 };
		int m = a.length;
		int n = b.length;
		sort(a, b, m, n);

	}

	private static void sort(int[] a, int[] b, int m, int n) {
		// TODO Auto-generated method stub
		int i = 0, j = 0;
		while (i < m && j < n) {
			if (a[i] <= b[j]) {
				System.out.println(a[i]);
				i++;
			} else {
				System.out.println(b[j]);
				j++;
			}
		}
		while (i < m) {
			System.out.println(a[i]);
			i++;
		}
		while (j < n) {
			System.out.println(b[j]);
			j++;
		}

	}

}
