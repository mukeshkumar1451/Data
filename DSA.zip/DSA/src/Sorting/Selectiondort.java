package Sorting;

public class Selectiondort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 7, 1, 5, 8, 4 };
		int n = arr.length;
		sort(arr, n);

	}

	private static void sort(int[] arr, int n) {
		// TODO Auto-generated method stub
		for (int i = 0; i < n; i++) {
			int minindex = i;
			for (int j = i + 1; j < n; j++) {
				if (arr[j] < arr[minindex]) {
					minindex = j;
				}
			}
			int temp = arr[minindex];
			arr[minindex] = arr[i];
			arr[i] = temp;

			System.out.print(arr[i] + " ");
		}

	}

}
