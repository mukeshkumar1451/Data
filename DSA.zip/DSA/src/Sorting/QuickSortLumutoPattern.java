package Sorting;

public class QuickSortLumutoPattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 10, 5, 30, 15, 7 };
		int low = 0;
		int high = arr.length - 1;

		quick(arr, low, high);

		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
	}

	private static void quick(int[] arr, int low, int high) {
		// TODO Auto-generated method stub
		if (low < high) {
			int mid = partition(arr, low, high);
			quick(arr, low, mid - 1);
			quick(arr, mid + 1, high);

		}

	}

	private static int partition(int[] arr, int low, int high) {
		// TODO Auto-generated method stub
		int pivot = arr[high];
		int i = low - 1;
		for (int j = low; j <= high - 1; j++) {
			if (arr[j] < pivot) {
				i++;
				int temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}
		int temp = arr[i + 1];
		arr[i + 1] = arr[high];
		arr[high] = temp;
		return (i + 1);
	}

}
