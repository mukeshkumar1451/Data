package Sorting;

public class KthElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 10, 5, 30, 15, 7 };
		int n = arr.length;
		int k = 2;

		int res = element(arr, n, k);

		System.out.println(res);

	}

	private static int element(int[] arr, int n, int k) {
		// TODO Auto-generated method stub
		int l = 0, h = n - 1;
		while (l <= h) {
			int p = partition(arr, l, h);
			if (p <= k - 1) {
				return p;
			} else if (p > k - 1) {
				h = p - 1;
			} else {
				l = p + 1;
			}

		}
		return -1;
	}

	private static int partition(int[] arr, int l, int h) {
		// TODO Auto-generated method stub
		int pivot = arr[h];
		int i = l - 1;

		for (int j = l; j <= h - 1; j++) {
			if (arr[j] < pivot) {
				i++;
				int temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}
		int temp = arr[i + 1];
		arr[i + 1] = arr[i];
		arr[i] = temp;

		return (i + 1);
	}

}
