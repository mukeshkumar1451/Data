package Sorting;

import java.util.Arrays;

public class ChocolateDisturbtionProblem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 7, 3, 1, 8, 9, 12, 56 };
		int n = arr.length;
		int m = 3;

		int res = choco(arr, n, m);
		System.out.println(res);

	}

	private static int choco(int[] arr, int n, int m) {
		// TODO Auto-generated method stub
		if (m > n) {
			return 1;
		}
		Arrays.sort(arr);

		int res = arr[m - 1] - arr[0];
		for (int i = 1; (i + m - 1) < n; i++) {
			res = Math.min(res, arr[i + m - 1] - arr[i]);
		}
		return res;
	}

}
