package Recursion;

public class Test3 {

	public static void main(String[] args) {
		fun(7);
	}

	private static void fun(int n) {
		if (n == 0) {
			return;
		}
		System.out.println(n);
		fun(n / 2);
		System.out.println(n);
	}

}
