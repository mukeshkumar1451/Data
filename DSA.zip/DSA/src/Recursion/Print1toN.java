package Recursion;

public class Print1toN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n = 4;
		PrintNumber(n);

	}

	private static void PrintNumber(int n) {
		// TODO Auto-generated method stub
		if (n == 0) {
			return;
		}

		PrintNumber(n - 1);
		System.out.println(n);

	}

}
