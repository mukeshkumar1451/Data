package Recursion;

public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int total = fun(4);
		System.out.println(total);

	}

	private static int fun(int n) {
		// TODO Auto-generated method stub
		if (n == 1) {
			return 0;
		} else {
			return 1 + fun(n / 2);
		}

	}

}
