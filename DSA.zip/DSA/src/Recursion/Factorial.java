package Recursion;

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n = 5;
		int k = 1;
		int sum = fact(n, k);
		System.out.println(sum);

	}

	private static int fact(int n, int k) {
		// TODO Auto-generated method stub
		if (n == 0 || n == 1) {
			return k;
		}

		return fact(n - 1, k * n);
	}

}
