package Hashing;

public class LongestSubarraySpan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] a = { 0, 1, 0, 0, 0, 0 };
		int[] b = { 1, 0, 1, 0, 0, 1 };
		int res = longsub(a, b);
		System.out.println(res);

	}

	private static int longsub(int[] a, int[] b) {
		// TODO Auto-generated method stub
		int res = 0;
		for (int i = 0; i < a.length; i++) {
			int sum1 = 0, sum2 = 0;
			for (int j = i; j < b.length; j++) {
				sum1 += a[j];
				sum2 += b[j];

				if (sum1 == sum2) {
					res = Math.max(res, j - 1 + 1);
				}
			}
		}
		return res;
	}

}
