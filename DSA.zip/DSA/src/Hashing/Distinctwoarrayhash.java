package Hashing;

import java.util.HashSet;

public class Distinctwoarrayhash {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a = { 10, 20, 30 };
		int[] b = { 20, 30 };
		count(a, b);

	}

	private static void count(int[] a, int[] b) {
		// TODO Auto-generated method stub
		HashSet<Integer> s = new HashSet<Integer>();
		for (int i : a) {
			s.add(i);
		}

		for (int i : b) {
			s.add(i);
		}
		System.out.println(s.size());
	}

}
