package Hashing;

import java.util.HashMap;
import java.util.Map;

public class FrequentCountHash {
	public static void main(String[] args) {
		Integer[] arr = { 1, 3, 1 };
		int n = arr.length;

		Count(arr);
		// System.out.println(res);

	}

	private static void Count(Integer[] arr) {
		// TODO Auto-generated method stub
		HashMap<Integer, Integer> h = new HashMap<Integer, Integer>();
		for (int i : arr) {
			h.put(i, h.getOrDefault(i, 0) + 1);
		}
		for (Map.Entry<Integer, Integer> e : h.entrySet()) {
			System.out.println(e.getKey() + " " + e.getValue());
		}

	}

}
