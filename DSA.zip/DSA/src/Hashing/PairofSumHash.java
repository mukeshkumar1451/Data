package Hashing;

import java.util.HashSet;
import java.util.Set;

public class PairofSumHash {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] a = { 8, 3, 2, 4, 5 };
		int sum = 6;
		boolean s = count(a, sum);
		System.out.println(s);

	}

	private static boolean count(int[] a, int sum) {
		// TODO Auto-generated method stub
		Set<Integer> s = new HashSet<Integer>();
		for (int i : a) {
			if (s.contains(sum - i)) {
				return true;
			}
			s.add(i);
		}
		return false;

	}

}
