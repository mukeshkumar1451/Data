package Hashing;

import java.util.HashMap;
import java.util.Map;

public class HashMapexample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<String, Integer> m = new HashMap<String, Integer>();
		m.put("m", 1);
		m.put("n", 2);
		m.put("s", 8);

		System.out.println(m);
		System.out.println(m.size());

		for (Map.Entry<String, Integer> e : m.entrySet()) {
			System.out.println(e.getKey() + " " + e.getValue());
		}
		System.out.println(m.get("s"));

	}

}
