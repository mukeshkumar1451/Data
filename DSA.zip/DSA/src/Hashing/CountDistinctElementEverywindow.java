package Hashing;

public class CountDistinctElementEverywindow {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 10, 20, 30, 40 };
		int k = 3;
		int n = arr.length;
		windowcount(arr, k, n);

	}

	private static void windowcount(int[] arr, int k, int n) {
		// TODO Auto-generated method stub

		for (int i = 0; i <= n - k; i++) {
			int count = 0;
			for (int j = 0; j < k; j++) {
				boolean flag = false;
				for (int p = 0; p < k; p++) {
					if (arr[i + j] == arr[i + p]) {
						flag = true;
						break;
					}
				}
				if (flag == true) {
					count++;
				}

			}
			System.out.println(count);

		}

	}

}
