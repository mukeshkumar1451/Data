package Hashing;

import java.util.Arrays;

public class NbyKOccurance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 10, 10, 20, 30, 20, 10, 10, 20, 20, 30 };
		int k = 2;
		int n = arr.length;

		occurance(arr, k, n);

	}

	private static void occurance(int[] arr, int k, int n) {
		// TODO Auto-generated method stub
		Arrays.sort(arr);
		int i = 1, count = 1;
		while (i < n) {
			while (i < n && arr[i] == arr[i - 1]) {
				count++;
				i++;
			}
			if (count > n / k) {
				System.out.println(arr[i - 1]);
			}
			count = 1;
			i++;
		}

	}

}
