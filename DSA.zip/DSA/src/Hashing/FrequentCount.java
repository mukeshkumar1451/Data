package Hashing;

public class FrequentCount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 1, 3, 1 };
		int n = arr.length;

		Count(arr, n);
		// System.out.println(res);

	}

	private static void Count(int[] arr, int n) {
		// TODO Auto-generated method stub
		// int count = 0;
		for (int i = 0; i < n; i++) {
			boolean flag = false;
			for (int j = 0; j < i; j++) {
				if (arr[i] == arr[j]) {
					flag = true;
					break;
				}
			}
			if (flag == true) {
				continue;
			}

			int freq = 1;
			for (int j = i + 1; j < n; j++) {
				if (arr[i] == arr[j]) {
					freq++;
				}
			}
			System.out.println(arr[i] + " " + freq);
		}
	}

}
