package Hashing;

import java.util.HashSet;

public class Subarraywithsum {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer[] arr = { 5, 3, 2, -1 };
		int sum = 11;

		boolean flag = Subsum(arr, sum);
		System.out.println(flag);

	}

	private static boolean Subsum(Integer[] arr, int sum) {
		// TODO Auto-generated method stub
		HashSet<Integer> s = new HashSet<Integer>();
		int presum = 0;
		for (int i : arr) {
			presum += i;

			if (presum == sum) {
				return true;
			}
			if (s.contains(presum - sum)) {
				return true;
			}
			s.add(presum);
		}
		return false;
	}

}
