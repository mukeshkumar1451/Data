package Hashing;

import java.util.HashSet;

public class Intersectiontwoarrayhash {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a = { 10, 20, 30 };
		int[] b = { 20, 30 };
		count(a, b);
	}

	private static void count(int[] a, int[] b) {
		// TODO Auto-generated method stub

		HashSet<Integer> s = new HashSet<Integer>();

		for (int i = 0; i < b.length; i++) {
			s.add(b[i]);
		}

		for (int i = 0; i < a.length; i++) {
			if (s.contains(a[i])) {
				System.out.println(a[i]);
			}

		}

	}

}
