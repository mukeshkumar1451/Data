package Hashing;

import java.util.Arrays;
import java.util.HashSet;

public class CountDistinctElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer[] arr = { 1, 3, 1, 5, 2, 3 };

		int res = CountDistinct(arr);
		System.out.println(res);

	}

	private static int CountDistinct(Integer[] arr) {
		// TODO Auto-generated method stub
		HashSet<Integer> s = new HashSet<Integer>(Arrays.asList(arr));
		return s.size();
	}

}
