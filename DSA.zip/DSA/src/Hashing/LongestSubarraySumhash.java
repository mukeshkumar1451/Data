package Hashing;

import java.util.HashMap;

public class LongestSubarraySumhash {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Integer[] a = { 3, 1, 0, 1, 8, 2, 3, 6 };
		int sum = 5;
		int n = a.length;
		int res = sumsub(a, n, sum);
		System.out.println(res);

	}

	private static int sumsub(Integer[] a, int n, int sum) {
		// TODO Auto-generated method stub
		// Set<Integer> s=new HashSet<Integer>();
		HashMap<Integer, Integer> s = new HashMap<Integer, Integer>();
		int presum = 0, res = 0;
		for (int i = 0; i < n; i++) {
			presum += a[i];

			if (presum == sum) {
				res = i + 1;
			}
			if (s.containsKey(presum) == false) {
				s.put(presum, i);
			}
			if (s.containsKey(presum - sum)) {
				res = Math.max(res, i - s.get(presum - sum));
			}

		}
		return res;
	}

}
