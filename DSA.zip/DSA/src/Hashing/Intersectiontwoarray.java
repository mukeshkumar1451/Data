package Hashing;

public class Intersectiontwoarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a = { 10, 20, 30 };
		int[] b = { 20, 30 };
		count(a, b);

	}

	private static void count(int[] a, int[] b) {
		// TODO Auto-generated method stub

		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < b.length; j++) {
				if (a[i] == b[j]) {
					System.out.println(a[i]);
				}
			}
		}
	}

}
