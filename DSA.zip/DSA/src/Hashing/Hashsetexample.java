package Hashing;

import java.util.HashSet;
import java.util.Iterator;

public class Hashsetexample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<String> h = new HashSet<String>();
		h.add("maa");
		h.add("mad");
		h.add("mas");
		System.out.println(h);
		System.out.println(h.size());
		h.remove("mad");
		System.out.println(h.size());

		System.out.println(h.contains("mas"));
		for (String s : h) {
			System.out.println(s + " ");
		}
		System.out.println(h.isEmpty());
		Iterator<String> i = h.iterator();
		while (i.hasNext()) {
			System.out.println(i.next());
		}

	}

}
