package Hashing;

public class LongestSubarraySumZeroorone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = { 1, 1, 1, 0, 1, 0 };
		int n = arr.length;
		int res = longsum(arr, n);
		System.out.println(res);

	}

	private static int longsum(int[] arr, int n) {
		// TODO Auto-generated method stub
		int res = 0;
		for (int i = 0; i < n; i++) {
			int c1 = 0, c0 = 0;
			for (int j = i; j < n; j++) {
				if (arr[j] == 0) {
					c0++;
				} else {
					c1++;
				}
				if (c0 == c1) {

					res = Math.max(res, c0 + c1);
				}

			}
		}
		return res;
	}

}
