package Hashing;

public class LongestSubarraySum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] a = { 3, 1, 0, 1, 8, 2, 3, 6 };
		int sum = 5;
		int n = a.length;
		int res = sumsub(a, n, sum);
		System.out.println(res);

	}

	private static int sumsub(int[] a, int n, int sum) {
		// TODO Auto-generated method stub
		int res = 0;
		for (int i = 0; i < n; i++) {
			int presum = 0;
			for (int j = i; j < n; j++) {
				presum += a[j];
				if (presum == sum) {
					res = Math.max(res, j - i + 1);
				}
			}
		}

		return res;
	}

}
