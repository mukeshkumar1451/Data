package Hashing;

public class CountDistinctElementWOHash {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 1, 3, 1, 5, 2, 3 };
		int n = arr.length;

		int res = CountDistinct(arr, n);
		System.out.println(res);

	}

	private static int CountDistinct(int[] arr, int n) {
		// TODO Auto-generated method stub
		int count = 0;
		for (int i = 0; i < n; i++) {
			boolean flag = false;
			for (int j = 0; j < i; j++) {
				if (arr[i] == arr[j]) {
					flag = true;
					break;
				}
			}
			if (flag == false) {
				count++;
			}

		}
		return count;

	}

}
