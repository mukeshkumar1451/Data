package Hashing;

import java.util.Arrays;

public class LongestConsecutiveSubSequence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a = { 1, 9, 3, 2, 4, 7 };
		int res = longsub(a);
		System.out.println(res);

	}

	private static int longsub(int[] a) {
		// TODO Auto-generated method stub
		Arrays.sort(a);
		int res = 1, curr = 1;
		for (int i = 1; i < a.length; i++) {
			if (a[i] == a[i - 1] + 1) {
				curr++;
			} else if (a[i] != a[i - 1]) {
				res = Math.max(res, curr);
				curr = 1;
			}
		}
		return Math.max(res, curr);
	}

}
