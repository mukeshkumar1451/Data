package Hashing;

import java.util.HashSet;

public class Subarraywithsumzero {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer[] arr = { 4, -3, 2, 1 };
		boolean flag = sum(arr);
		System.out.println(flag);

	}

	private static boolean sum(Integer[] arr) {
		// TODO Auto-generated method stub
		HashSet<Integer> s = new HashSet<Integer>();
		int presum = 0;
		for (int i = 0; i < arr.length; i++) {
			presum += arr[i];
			if (s.contains(presum)) {
				return true;
			}
			if (presum == 0) {
				return true;
			}
			s.add(presum);
		}

		return false;
	}

}
