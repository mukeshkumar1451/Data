package LinkedList;

public class Reverse {

	Node head;
	private int size;

	Reverse() {
		this.size = 0;
	}

	class Node {
		int data;
		Node next;

		public Node(int data) {
			this.data = data;
			this.next = null;
			size++;
		}

	}

	private void addFirst(int data) {
		// TODO Auto-generated method stub
		Node newNode = new Node(data);
		if (head == null) {
			head = newNode;
			return;
		}
		newNode.next = head;
		head = newNode;

	}

	private void addLast(int data) {
		// TODO Auto-generated method stub
		Node newNode = new Node(data);
		if (head == null) {
			head = newNode;
			return;
		}

		Node currNode = head;
		while (currNode.next != null) {
			currNode = currNode.next;
		}
		currNode.next = newNode;
	}

	private void printList() {
		// TODO Auto-generated method stub

		if (head == null) {
			System.out.println("List is empty");
			return;
		}

		Node currNode = head;
		while (currNode != null) {
			System.out.print(currNode.data + "->");
			currNode = currNode.next;
		}
		System.out.print("null");

	}

	public void deleteFirst() {
		if (head == null) {
			System.out.println("List is empty");
			return;
		}
		size--;
		head = head.next;

	}

	public void deleteLast() {
		if (head == null) {
			System.out.println("List is empty");
			return;
		}
		size--;
		if (head.next == null) {
			head = null;
			return;
		}

		Node SecondLast = head;
		Node LastNode = head.next;

		while (LastNode.next != null) {
			LastNode = LastNode.next;
			SecondLast = SecondLast.next;
		}
		SecondLast.next = null;
	}

	public int getSize() {
		return size;
	}

	public void reverseIterative() {

		if (head == null || head.next == null) {
			return;
		}

		Node prevNode = head;
		Node currNode = head.next;
		while (currNode != null) {
			Node nextNode = currNode.next;
			currNode.next = prevNode;

			// update
			prevNode = currNode;
			currNode = nextNode;

		}
		head.next = null;
		head = prevNode;

	}

	public Node reverseRecursive(Node head) {
		if (head == null || head.next == null) {
			return head;
		}
		Node newNode = reverseRecursive(head.next);
		head.next.next = head;
		head.next = null;
		return newNode;

	}

	public Node swapPairs(Node head) {

		if (head == null || head.next == null) {
			return head;
		}

		Node first = head;
		Node sec = head.next;
		Node prev = null;
		while (first != null && sec != null) {
			Node third = sec.next;
			sec.next = first;
			first.next = third;
			if (prev != null) {
				prev.next = sec;
			} else {
				head = sec;
			}

			// update
			prev = first;
			first = third;
			if (third != null) {
				sec = third.next;
			} else {
				sec = null;
			}

		}
		return head;

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Reverse list = new Reverse();

		list.addLast(1);
		list.addLast(2);
		list.addLast(3);
		// list.addLast(4);
		list.printList();

		System.out.println();
		list.head = list.swapPairs(list.head);
		list.printList();

	}

}
