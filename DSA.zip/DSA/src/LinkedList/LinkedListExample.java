package LinkedList;

public class LinkedListExample {
	Node head;
	private int size;

	LinkedListExample() {
		this.size = 0;
	}

	class Node {
		String data;
		Node next;

		public Node(String data) {
			this.data = data;
			this.next = null;
			size++;
		}

	}

	private void addFirst(String data) {
		// TODO Auto-generated method stub
		Node newNode = new Node(data);
		if (head == null) {
			head = newNode;
			return;
		}
		newNode.next = head;
		head = newNode;

	}

	private void addLast(String data) {
		// TODO Auto-generated method stub
		Node newNode = new Node(data);
		if (head == null) {
			head = newNode;
			return;
		}

		Node currNode = head;
		while (currNode.next != null) {
			currNode = currNode.next;
		}
		currNode.next = newNode;
	}

	private void printList() {
		// TODO Auto-generated method stub

		if (head == null) {
			System.out.println("List is empty");
			return;
		}

		Node currNode = head;
		while (currNode != null) {
			System.out.print(currNode.data + "->");
			currNode = currNode.next;
		}
		System.out.print("null");

	}

	public void deleteFirst() {
		if (head == null) {
			System.out.println("List is empty");
			return;
		}
		size--;
		head = head.next;

	}

	public void deleteLast() {
		if (head == null) {
			System.out.println("List is empty");
			return;
		}
		size--;
		if (head.next == null) {
			head = null;
			return;
		}

		Node SecondLast = head;
		Node LastNode = head.next;

		while (LastNode.next != null) {
			LastNode = LastNode.next;
			SecondLast = SecondLast.next;
		}
		SecondLast.next = null;
	}

	public int getSize() {
		return size;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LinkedListExample list = new LinkedListExample();

		list.addFirst("a");
		list.addFirst("b");
		list.printList();
		System.out.println();

		list.addLast("k");
		list.printList();
		System.out.println();
		list.addLast("t");
		list.printList();

		System.out.println();
		list.deleteFirst();
		list.printList();

		System.out.println();
		list.deleteLast();
		list.printList();

		System.out.println();
		System.out.println(list.getSize());

	}

}
