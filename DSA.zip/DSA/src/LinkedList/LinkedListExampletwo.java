package LinkedList;

import java.util.LinkedList;

public class LinkedListExampletwo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<String> list = new LinkedList<String>();
		list.addFirst("a");
		list.addLast("c");
		list.add("k");
		list.add(1, "b");

		System.out.println(list);

		for (int i = 0; i < list.size(); i++) {
			System.out.print(list.get(i) + "->");
		}
		System.out.print("null");

		System.out.println();

		// list.getFirst();
		System.out.println(list.getFirst());

	}

}
