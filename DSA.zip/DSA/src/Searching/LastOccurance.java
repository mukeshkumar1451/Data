package Searching;

public class LastOccurance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 10, 20, 20, 40, 50 };
		int n = arr.length;
		int k = 20;
		// System.out.println(1 / 2);
		int res = lastOccurence(arr, n, k);
		System.out.println(res);

	}

	private static int lastOccurence(int[] arr, int n, int k) {
		// TODO Auto-generated method stub

		for (int i = n - 1; i >= 0; i--) {
			if (arr[i] == k) {
				return i;
			}

		}
		return -1;
	}

}
