package Searching;

public class InfinateSearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 10, 10, 20, 20, 20, 40, 50 };
		int n = arr.length;
		int k = 20;
		// System.out.println(1 / 2);
		int res = infinateOccurence(arr, n, k);
		System.out.println(res);

	}

	private static int infinateOccurence(int[] arr, int n, int k) {
		// TODO Auto-generated method stub
		int i = 0;
		while (true) {
			if (arr[i] == k) {
				return i;
			}
			if (arr[i] > k) {
				return -1;
			}
			i++;
		}
	}

}
