package Searching;

public class TwoPointerApproach {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 2, 5, 8, 12, 30 };
		int n = arr.length;
		int x = 17;

		boolean check = approach(arr, n, x);
		System.out.println(check);

	}

	private static boolean approach(int[] arr, int n, int x) {
		// TODO Auto-generated method stub
		for (int i = 0; i < n; i++) {
			for (int j = 1; j < n; j++) {
				if (arr[i] + arr[j] == x) {
					return true;
				}
			}

		}
		return false;
	}

}
