package Searching;

public class Peakelement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 6, 7, 8, 10, 12 };
		int n = arr.length;
		int res = peak(arr, n);

		for (int i = 0; i < n; i++) {
			System.out.println(arr[i]);
		}

	}

	private static int peak(int[] arr, int n) {
		// TODO Auto-generated method stub
		if (n == 1) {
			return arr[0];
		}

		if (arr[0] >= arr[1]) {
			return arr[0];
		}
		if (arr[n - 1] <= arr[n - 2]) {
			return arr[n - 1];
		}
		for (int i = 1; i < n; i++) {
			if (arr[i] >= arr[i - 1] && arr[i] >= arr[i + 1]) {
				return arr[i];
			}
		}
		return -1;
	}

}
