package Searching;

public class AllocateMinimumPage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 10, 20, 30, 40 };
		int n = arr.length;
		int k = 2;
		int res = minpages(arr, n, k);
		System.out.println(res);

	}

	private static int minpages(int[] arr, int n, int k) {
		// TODO Auto-generated method stub
		if (k == 1) {
			return sum(arr, 0, n - 1);
		}
		if (n == 1) {
			return arr[0];
		}
		int res = Integer.MAX_VALUE;

		for (int i = 1; i < n; i++) {
			res = Math.min(res, Math.max(minpages(arr, i, k - 1), sum(arr, i, n - 1)));
		}

		return res;
	}

	private static int sum(int[] arr, int a, int b) {
		// TODO Auto-generated method stub
		int sm = 0;
		for (int i = a; i <= b; i++) {
			sm = sm + arr[i];
		}
		return sm;
	}

}
