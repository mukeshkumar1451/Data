package Searching;

public class RepeatingElemet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 0, 2, 1, 4, 0, 2, 3 };
		int n = arr.length;
		int res = findRepeating(arr, n);
		System.out.println(res);

	}

	private static int findRepeating(int[] arr, int n) {
		// TODO Auto-generated method stub
		int slow = arr[0], fast = arr[0];
		do {
			slow = arr[slow];
			fast = arr[arr[fast]];
		} while (slow != fast);
		slow = arr[0];
		while (slow != fast) {
			slow = arr[slow];
			fast = arr[fast];
		}

		return slow;
	}

}
