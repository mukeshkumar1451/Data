package Searching;

public class BinarySearch {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 10, 20, 30, 40, 50 };
		int n = arr.length;
		int k = 40;
		System.out.println(1 / 2);
		int res = BinarySearch(arr, n, k);
		System.out.println(res);

	}

	private static int BinarySearch(int[] arr, int n, int k) {
		// TODO Auto-generated method stub

		int low = 0, high = n - 1;

		while (low < high) {
			int mid = (low + high) / 2;
			if (arr[mid] == k) {
				return mid;
			}
			if (arr[mid] > k) {
				high = mid - 1;
			} else {
				low = mid + 1;
			}
		}
		return -1;
	}

}
