package Searching;

public class SecondOccurance {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 10, 10, 20, 20, 20, 40, 50 };
		int n = arr.length;
		int k = 20;
		// System.out.println(1 / 2);
		int res = SecondOccurence(arr, n, k);
		System.out.println(res);
	}

	private static int SecondOccurence(int[] arr, int n, int k) {
		// TODO Auto-generated method stub

		int count = 0;
		for (int i = 0; i < n; i++) {
			if (arr[i] == k) {
				count++;
			}
			if (count == 2) {
				return i;
			}

		}
		if (count < 2) {
			return k;
		}
		return -1;
	}

}
