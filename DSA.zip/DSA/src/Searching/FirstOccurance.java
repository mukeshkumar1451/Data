package Searching;

public class FirstOccurance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 10, 20, 20, 40, 50 };
		int n = arr.length;
		int k = 20;
		// System.out.println(1 / 2);
		int res = FirstOccurence(arr, n, k);
		System.out.println(res);

	}

	private static int FirstOccurence(int[] arr, int n, int k) {
		// TODO Auto-generated method stub
		for (int i = 0; i < n; i++) {
			if (arr[i] == k) {
				return i;
			}
		}
		return -1;
	}

}
