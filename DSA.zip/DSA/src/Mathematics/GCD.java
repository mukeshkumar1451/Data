package Mathematics;

public class GCD {
	public static int gcdval(int a, int b) {

		// method 1
//		int result = Math.min(a, b);
//		while (result > 0) {
//			if (a % result == 0 && b % result == 0) {
//				break;
//			}
//			result--;
//		}
//		return result;

		// method 2 euclidean algorithm
//		while (a != b) {
//			if (a > b) {
//				a = a - b;
//			} else {
//				b = b - a;
//			}
//		}
//		return a;

		// method 3 euclidean algorithm

		if (a == 0) {
			return b;
		}
		return gcdval(b % a, a);//

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 4;
		int b = 6;

		int results = gcdval(a, b);
		System.out.println(results);

	}

}
