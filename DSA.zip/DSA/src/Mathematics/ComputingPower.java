package Mathematics;

public class ComputingPower {

	public static int powers(int a, int b) {

		if (b == 0) {
			return 1;
		}
		int temp = powers(a, b / 2);
		temp = temp * temp;
		if (b % 2 == 0) {
			return temp;
		} else {
			return temp * a;
		}

		// return (int) Math.pow(a, b);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 2;
		int b = 3;

		int result = powers(a, b);
		System.out.println(result);

	}

}
