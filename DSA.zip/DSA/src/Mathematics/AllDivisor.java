package Mathematics;

public class AllDivisor {
	public static void divisor(int n) {
		if (n < 0) {
			System.out.println(n);
		}

		for (int i = 1; i <= n; i++) {
			if (n % i == 0) {
				System.out.println(i);
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 15;
		divisor(n);

	}

}
