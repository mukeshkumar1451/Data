package Mathematics;

public class countDigit {
	public static int countNumber(int number) {
		int count = 0;
		{
			while (number != 0) {
				number = number / 10;
				count++;
			}
			return count;
		}

	}

	public static void main(String[] args) {
		int number = 234567;
		int totalcount = countNumber(number);
		System.out.println(totalcount);
	}

}
