package Mathematics;

public class factorialNumber {

	public static int isFactorial(int number) {
//		int fact = 1;
//
//		for (int i = 1; i <= number; i++) {
//			fact = fact * i;
//		}
//		return fact;

		if (number == 0) {
			return 1;
		}

		return number * isFactorial(number - 1);

	}

	public static void main(String[] args) {
		int number = 6;
		int sum = isFactorial(number);
		System.out.println(sum);
	}

}