package Mathematics;

public class iterativepower {

	public static int itpowers(int x, int n) {
		int res = 1;
		while (n > 0) {
			if (n % 2 != 0) {
				res = res * x;
			}
			x = x * x;
			n = n / 2;
		}

		return res;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int x = 2;
		int n = 3;

		int result = itpowers(x, n);
		System.out.println(result);

	}

}
