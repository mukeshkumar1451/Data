package Mathematics;

public class primeFactor {

	public static boolean isPrime(int n) {
		if (n == 1) {
			return false;
		}
		if (n == 2 || n == 3) {
			return true;
		}
		if (n % 2 == 0 || n % 3 == 0) {
			return false;
		}

		for (int i = 5; i * i <= n; i = i + 6) {
			if (n % i == 0 || n % (i + 2) == 0) {
				return false;
			}
		}
		return true;

	}

	public static void primeFactors(int n) {
//method1
//		for (int i = 2; i < n; i++) {
//			if (isPrime(i)) {
//				int x = i;
//				while (n % x == 0) {
//					System.out.println(i);
//					x = x * i;
//				}
//			}
//			System.out.println();
//		}

		// method 2
		if (n == 1) {
			return;
		}
		for (int i = 2; i * i <= n; i++) {
			while (n % i == 0) {
				System.out.println(i);
				n = n / i;
			}
		}
		if (n > 1) {
			System.out.println(n);
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n = 12;

		primeFactors(n);

	}

}
