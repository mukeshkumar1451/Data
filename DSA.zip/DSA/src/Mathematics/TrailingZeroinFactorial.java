package Mathematics;

public class TrailingZeroinFactorial {

	public static int trailZeroFact(int n) {
//		int fact = 1;
//		for (int i = 1; i <= n; i++) {
//			fact = fact * i;
//		}
//		int count = 0;
//
//		while (fact % 10 == 0) {
//			count++;
//			fact = fact / 10;
//		}
//		return count;
		int res = 0;
		for (int i = 5; i <= n; i = i * 5) {
			res = res + n / i;
		}
		return res;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 3;

		int totalzero = trailZeroFact(n);
		System.out.println(totalzero);

	}

}
