package Mathematics;

public class Palindromechar {
	public static boolean isPalindromechar(String s) {
		s = s.toLowerCase();
		String reverse = "";
		for (int i = s.length() - 1; i >= 0; i--) {
			reverse = reverse + s.charAt(i);
		}
		return s.equals(reverse);
	}

	public static void main(String args[]) {
		String s = "smss";
		boolean palin = isPalindromechar(s);
		System.out.println(palin ? "yes" : "no");
	}

}
