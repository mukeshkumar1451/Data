package Mathematics;

public class palindrome {
	public static boolean palindromeNumber(int number) {
		int orginalnumber = number;
		int reversenumber = 0;

		if (number < 0) {
			return false;
		}

		while (number != 0) {
			int digit = number % 10;
			reversenumber = reversenumber * 10 + digit;
			number /= 10;
		}

		return orginalnumber == reversenumber;
	}

	public static void main(String[] args) {
		int number = 818;

		boolean ispalindrome = palindromeNumber(number);

		System.out.println(ispalindrome ? "yes" : "no");
	}

}
