package Mathematics;

public class LCM {
	public static int gcd(int a, int b) {

		if (a == 0) {
			return b;
		}
		return gcd(b % a, a);//

	}

	public static int lcmval(int a, int b) {
		// method 1
//		int res = Math.max(a, b);
//		while (true) {
//			if (res % a == 0 && res % b == 0) {
//				break;
//			}
//			res++;
//		}
//		return res;

		return (a * b) / gcd(a, b);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 4;
		int b = 6;

		int results = lcmval(a, b);
		System.out.println(results);

	}

}
