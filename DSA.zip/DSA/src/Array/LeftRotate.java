package Array;

public class LeftRotate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 10, 17, 12, 19 };
		int n = arr.length;

		leftmove(arr, n);

		for (int i = 0; i < n; i++) {
			System.out.println(arr[i]);
		}

	}

	private static void leftmove(int[] arr, int n) {
		// TODO Auto-generated method stub

		int temp = arr[0];
		for (int i = 1; i < n; i++) {
			arr[i - 1] = arr[i];

		}
		arr[n - 1] = temp;
	}

}
