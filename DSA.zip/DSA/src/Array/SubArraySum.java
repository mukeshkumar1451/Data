package Array;

public class SubArraySum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 1, 4, 20, 3, 10, 5 };
		int n = arr.length;
		int s = 33;

		boolean res = sumsubarray(arr, n, s);
		System.out.println(res);

	}

	private static boolean sumsubarray(int[] arr, int n, int s) {
		// TODO Auto-generated method stub

		for (int i = 0; i < n; i++) {
			int sum = 0;
			for (int j = i; j < n; j++) {
				sum = sum + arr[j];
				System.out.println(sum);
				if (sum == s) {
					return true;

				}

			}

		}
		return false;
	}

}
