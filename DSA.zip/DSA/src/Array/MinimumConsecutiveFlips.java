package Array;

public class MinimumConsecutiveFlips {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 1, 1, 0, 0, 0, 1 };
		int n = arr.length;
		flips(arr, n);
	}

	private static void flips(int[] arr, int n) {
		// TODO Auto-generated method stub

		for (int i = 1; i < n; i++) {
			if (arr[i] != arr[i - 1]) {
				if (arr[i] != arr[0]) {
					System.out.print("from " + i + " to ");
				} else {
					System.out.print(i - 1);
				}
			}

			if (arr[n - 1] != arr[0]) {
				System.out.println(n - 1);
			}
		}

	}

}
