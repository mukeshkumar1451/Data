package Array;

public class MaxLengthEvenOddSubArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 5, 10, 20, 6, 3, 8 };
		int n = arr.length;
		int res = maxEvenOdd(arr, n);
		System.out.println(res);

	}

	private static int maxEvenOdd(int[] arr, int n) {
		// TODO Auto-generated method stub
		int res = 1, count = 1;
		for (int i = 1; i < n; i++) {
			if ((arr[i] % 2 == 0 && arr[i - 1] % 2 != 0) || (arr[i] % 2 != 0 && arr[i - 1] % 2 == 0)) {
				count++;
				res = Math.max(res, count);
			} else {
				count = 1;
			}
		}
		return res;
	}

}
