package Array;

public class equlibriumPoint {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 3, 4, 8, -9, 9, 7 };

		int n = arr.length;
		boolean res = eqPoint(arr, n);
		System.out.println(res);

	}

	private static boolean eqPoint(int[] arr, int n) {
		// TODO Auto-generated method stub
		for (int i = 0; i < n; i++) {
			int ls = 0, rs = 0;
			System.out.print(i + " ");
			for (int j = 0; j < i; j++) {
				ls = ls + arr[j];
				System.out.print(ls + "ls ");
			}
			for (int k = i + 1; k < n; k++) {
				rs = rs + arr[k];
				System.out.print(rs + "rs ");
			}

			if (ls == rs) {
				return true;
			}

		}
		return false;
	}

}
