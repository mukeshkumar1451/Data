package Array;

public class MaxAppraeingelement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] left = { 1, 2, 5, 15 };
		int[] right = { 5, 8, 7, 18 };

		int res = appear(left, right);
		System.out.println(res);

	}

	private static int appear(int[] left, int[] right) {
		// TODO Auto-generated method stub
		int res = 0;

		for (int i = 0; i < right.length; i++) {
			int count = 1;
			for (int j = 1; j < right.length; j++) {
				if (right[i] == left[j]) {
					count++;
					System.out.println(right[i]);

				}
				res = Math.max(count, res);

			}

		}
		return res;
	}

}
