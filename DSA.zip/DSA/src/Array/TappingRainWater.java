package Array;

public class TappingRainWater {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 2, 0, 2 };
		int n = arr.length;

		int result = rainwater(arr, n);
		System.out.println("----");
		System.out.println(result);
	}

	private static int rainwater(int[] arr, int n) {
		// TODO Auto-generated method stub

		int res = 0;
		int[] lmax = new int[n];
		int[] rmax = new int[n];

		lmax[0] = arr[0];
		System.out.println(lmax[0]);
		for (int i = 1; i < n; i++) {
			lmax[i] = Math.max(arr[i], lmax[i - 1]);
			// System.out.println(lmax[i]);
		}

		// System.out.println("---------");
		rmax[n - 1] = arr[n - 1];
		// System.out.println(rmax[n - 1]);
		for (int i = n - 2; i >= 0; i--) {
			rmax[i] = Math.max(arr[i], rmax[i + 1]);
			// System.out.println(rmax[i]);

		}

		for (int i = 1; i < n - 1; i++) {
			res = res + (Math.min(lmax[i], rmax[i]) - arr[i]);
		}

		return res;
	}

}
