package Array;

public class WindowSlidingTechnique {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 1, 8, 30, -5, 20, 7 };
		int n = arr.length;
		int k = 3;

		int res = sliding(arr, n, k);
		System.out.println(res);

	}

	private static int sliding(int[] arr, int n, int k) {
		// TODO Auto-generated method stub
		int res = Integer.MIN_VALUE;
		for (int i = 0; i + k - 1 < n; i++) {
			int sum = 0;
			for (int j = 0; j < k; j++) {
				sum = sum + arr[i + j];
			}
			res = Math.max(res, sum);
		}
		return res;

	}

}
