package Array;

public class WindowSlidingTechnique2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 1, 8, 30, -5, 20, 7 };
		int n = arr.length;
		int k = 3;

		int res = sliding2(arr, n, k);
		System.out.println(res);

	}

	private static int sliding2(int[] arr, int n, int k) {
		// TODO Auto-generated method stub

		int sum = 0;
		for (int i = 0; i < k; i++) {
			sum = sum + arr[i];
		}
		int res = sum;

		for (int i = k; i < n; i++) {
			sum = sum + arr[i] - arr[i - k];
			res = Math.max(sum, res);
		}

		return res;
	}

}
