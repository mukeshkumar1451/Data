package Array;

public class MoveZero {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 10, 12, 0, 19 };
		int n = arr.length;

		ZeroMovetoLast(arr, n);
		for (int i : arr) {
			System.out.println(i);
		}

	}

	private static void ZeroMovetoLast(int[] arr, int n) {
		// TODO Auto-generated method stub

		int count = 0;
		for (int i = 0; i < n; i++) {
			if (arr[i] != 0) {
				arr[count] = arr[i];
				count++;
			}

		}
		while (count < n) {
			arr[count++] = 0;
		}

	}

}
