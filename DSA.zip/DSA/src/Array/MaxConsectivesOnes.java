package Array;

public class MaxConsectivesOnes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean arr[] = { true, false, true, true, true, false, true };

		int res = consetivemax(arr);
		System.out.println(res);

	}

	private static int consetivemax(boolean[] arr) {
		// TODO Auto-generated method stub
		int res = 0, count = 0;
		int n = arr.length;
		for (int i = 0; i < n; i++) {
			if (arr[i] == false) {
				count = 0;
			} else {
				count++;
			}
			res = Math.max(res, count);
		}
		return res;
	}

}
