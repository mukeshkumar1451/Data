package Array;

public class MaxCircularSubArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 5, -2, 3, 4 };
		int n = arr.length;
		int res = cicularsum(arr, n);
		System.out.println(res);

	}

	private static int cicularsum(int[] arr, int n) {
		// TODO Auto-generated method stub
		int res = arr[0];

		for (int i = 0; i < n; i++) {
			int curmax = arr[i];
			int summax = arr[i];
			for (int j = 1; j < n; j++) {

				int index = (i + j) % n;
				summax += arr[index];
				curmax = Math.max(summax, curmax);

			}

			res = Math.max(curmax, res);

		}

		return res;
	}

}
