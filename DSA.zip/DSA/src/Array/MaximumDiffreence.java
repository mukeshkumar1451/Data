package Array;

public class MaximumDiffreence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 2, 3, 10, 6, 4, 8, 1 };

		int n = arr.length;
		int max = maxdif(arr, n);
		System.out.println(max);
	}

	private static int maxdif(int[] arr, int n) {
		// TODO Auto-generated method stub
		int res = arr[1] - arr[0];

		for (int i = 0; i < n - 1; i++) {
			for (int j = i + 1; j < n; j++) {
				res = Math.max(res, arr[j] - arr[i]);

			}

		}
		return res;

	}

}
