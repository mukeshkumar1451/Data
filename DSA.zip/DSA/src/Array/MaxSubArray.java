package Array;

public class MaxSubArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 5, 3, -1, 3, 6 };
		int n = arr.length;

		int res = MaxSub(arr, n);
		System.out.println(res);

	}

	private static int MaxSub(int[] arr, int n) {
		// TODO Auto-generated method stub
		int res = arr[0];
		int maxsum = arr[0];

		for (int i = 1; i < n; i++) {
			maxsum = Math.max(maxsum + arr[i], arr[i]);
		}
		res = Math.max(maxsum, res);
		return res;
	}

}
