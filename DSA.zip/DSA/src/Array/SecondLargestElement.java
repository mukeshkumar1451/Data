package Array;

public class SecondLargestElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 1, 13, 26, 3, 5 };
		int n = arr.length;

		int res = secLargestElement(arr, n);
		System.out.println(res);

	}

	private static int secLargestElement(int[] arr, int n) {
		int res = -1, largest = 0;

		for (int i = 0; i < n; i++) {
			if (arr[i] > arr[largest]) {
				res = largest;
				largest = i;
			} else if (arr[i] != arr[largest]) {
				if (res == -1 || arr[i] > arr[res]) {
					res = i;
				}
			}
		}
		return res;

	}

}
