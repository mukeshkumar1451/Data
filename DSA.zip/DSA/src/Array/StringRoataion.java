package Array;

public class StringRoataion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "Hello World";
		// int[] arr = { 1, 2, 3, 4, 5 };
		String[] str = s.split(" ");
		int n = str.length;
		int d = 3;

		leftmove(str, n, d);

		for (int i = 0; i < n; i++) {
			System.out.println(str[i]);
		}

	}

	private static void leftmove(String str[], int n, int d) {
		// TODO Auto-generated method stub

		// reverse(arr, 0, d - 1);
		// reverse(arr, d, n - 1);
		reverse(str, 0, n - 1);

	}

	private static void reverse(String arr[], int low, int high) {

		while (low < high) {
			String temp = arr[low];
			arr[low] = arr[high];
			arr[high] = temp;

			low++;
			high--;
		}

	}

}
