package Array;

public class StockBuyandSell {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 1, 5, 3, 2, 8, 12, };
		int n = arr.length;

		int profit = stock(arr, n);
		System.out.println(profit);

	}

	private static int stock(int[] arr, int n) {
		// TODO Auto-generated method stub

		int profit = 0;
		for (int i = 1; i < n; i++) {
			if (arr[i] > arr[i - 1]) {
				profit += (arr[i] - arr[i - 1]);
			}
		}
		return profit;
	}

}
