package Array;

public class SortedArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 10, 17, 12, 19 };

		boolean check = sorted(arr);

		System.out.println(check);

	}

	private static boolean sorted(int[] arr) {
		// TODO Auto-generated method stub
		int n = arr.length;

		for (int i = 1; i < n; i++) {
			// for (int j = i + 1; j < n; j++) {
			// if (arr[j] < arr[i]) {
			if (arr[i] < arr[i - 1]) {
				return false;

			}

			// }

		}
		return true;

	}

}
