package Array;

public class LeaderofRight {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 7, 6, 8, 2, 1 };
		int n = arr.length;

		leader(arr, n);

	}

	private static void leader(int[] arr, int n) {
		// TODO Auto-generated method stub

		int currentlead = arr[n - 1];
		System.out.println(currentlead);

		for (int i = n - 2; i >= 0; i--) {

			if (currentlead < arr[i]) {
				currentlead = arr[i];
				System.out.println(arr[i]);

			}
		}

//		for (int i = 0; i < n; i++) {
//			boolean flag = false;
//			for (int j = i + 1; j < n; j++) {
//				if (arr[i] <= arr[j]) {
//					flag = true;
//					break;
//				}
//			}
//			if (flag == false) {
//				System.out.println(arr[i]);
//			}
//		}

	}

}
