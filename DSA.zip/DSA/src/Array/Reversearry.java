package Array;

public class Reversearry {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 10, 17, 12, 19 };
		// int n = arr.length;
		reverse(arr);

		for (int i : arr) {
			System.out.println(i);
		}

		// System.out.println(check);
	}

	private static void reverse(int[] arr) {
		// TODO Auto-generated method stub
		int low = 0, high = arr.length - 1;

		while (low < high) {
			int temp = arr[low];
			arr[low] = arr[high];
			arr[high] = temp;
			low++;
			high--;
		}

	}

}
