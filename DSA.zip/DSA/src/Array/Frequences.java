package Array;

import java.util.HashMap;

public class Frequences {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 1, 3, 1, 2, 3, 3 };
		int n = arr.length;

		repetfreq(arr, n);

	}

	private static void repetfreq(int[] arr, int n) {
		// TODO Auto-generated method stub

		// method 1
//		int count = 1, i = 1;
//
//		while (i < n) {
//			while (i < n && arr[i] == arr[i - 1]) {
//				count++;
//				i++;
//			}
//			System.out.println(arr[i - 1] + " " + count);
//			i++;
//			count = 1;
//
//		}
//		if (n == 1 || arr[n - 1] != arr[n - 2]) {
//			System.out.println(arr[n] + " " + 1);
//		}

		HashMap<Integer, Integer> fequent = new HashMap<>();
		for (int i : arr) {
			fequent.put(i, fequent.getOrDefault(i, 0) + 1);
		}

		for (int j : fequent.keySet()) {
			System.out.println(j + " " + fequent.get(j));
		}

	}

}
