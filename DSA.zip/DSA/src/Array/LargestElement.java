package Array;

public class LargestElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 1, 13, 26, 3, 5 };

		int res = firstLargestElemet(arr);
		System.out.println(res);

	}

	private static int firstLargestElemet(int[] arr) {
		// TODO Auto-generated method stub
		int j = 0;
		for (int i = 1; i < arr.length; i++) {
			if (arr[i] > arr[j]) {
				j = i;
			}
		}
		return j;
	}

}
