package Bitwise;

public class AND {
	public static void main(String[] args) {
		int x = 3;
		int y = 6;
		System.out.println(x & y);
	}

}

// example

//1 0 - 0
//0 1 - 0
//0 0 - 0
//1 1 - 1

//8 4 2 1
//0 0 1 1
//0 1 1 0
//0 0 1 0-output