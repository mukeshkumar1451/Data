package Bitwise;

public class PowerofTwo {

	public static boolean powerTwo(int n) {
		if (n == 0) {
			return false;
		}
		while (n != 1) {
			if (n % 2 != 0) {
				return false;
			}
			n = n / 2;
		}
		return true;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 1;
		boolean check = powerTwo(n);
		System.out.println(check ? "yes" : "No");

	}

}
