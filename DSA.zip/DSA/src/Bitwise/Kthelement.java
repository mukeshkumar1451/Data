package Bitwise;

public class Kthelement {

	public static void isSet(int n, int k) {
		// method1
//		int x = 1;
//		for (int i = 0; i < (k - 1); i++) {
//			x = x * 2;
//		}
//		if ((n & x) != 0) {
//			System.out.println("Yes");
//		} else {
//			System.out.println("No");
//		}
		// method2
//		int x = (1 << (k - 1));
//		if ((n & x) != 0) {
//			System.out.println("Yes");

//		} else {
//			System.out.println("No");
//		}
		// method 3
		int x = (n >> (k - 1));
		if ((x & 1) != 0) {
			System.out.println("Yes");
		} else {
			System.out.println("No");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n = 5;
		int k = 3;
		isSet(n, k);

	}

}
