package Bitwise;

public class PowerSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s = "ab";
		powerofchar(s);
	}

	private static void powerofchar(String s) {
		// TODO Auto-generated method stub
		int n = s.length();
		int psize = (1 << n);
		for (int i = 0; i < psize; i++) {
			for (int j = 0; j < n; j++) {
				if ((i & (1 << j)) != 0) {
					System.out.println(j);

				}

			}
			System.out.println();

		}

	}

}
