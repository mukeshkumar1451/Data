package Bitwise;

public class TwooddOccuring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 10, 3, 3, 7 };
		int len = arr.length;

		oddoccurtwice(arr, len);

	}

	private static void oddoccurtwice(int[] arr, int len) {
		// TODO Auto-generated method stub
//		for (int i = 0; i < len; i++) {
//			int count = 0;
//			for (int j = 0; j < len; j++) {
//				if (arr[i] == arr[j]) {
//					count++;
//				}
//			}
//			if (count % 2 != 0) {
//				System.out.println(arr[i]);
//			}
//		}

		int res = arr[0];

		for (int i = 1; i < len; i++) {
			res = res ^ arr[i];
		}
		int k = (res & (~(res - 1)));
		System.out.println(k);

		int x = 0, y = 0;
		for (int i = 0; i < len; i++) {
			if ((arr[i] & k) != 0) {
				x = x ^ arr[i];
			} else {
				y = y ^ arr[i];
			}
		}
		System.out.println(x + " " + y);

	}

}
