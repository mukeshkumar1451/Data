package Bitwise;

public class CountSetBit {

	public static void initalize() {
		int[] table = new int[256];
		table[0] = 0;
		for (int i = 1; i < 256; i++) {
			table[i] = table[i & (i - 1)] + 1;
		}
	}

	public static int countSet(int n) {
		int[] table = new int[256];
		// int res = 0;
//		while (n > 0) {
//			if (n % 2 == 1) {
//				res++;
//
//			}
//			res = res + (n & 1);
//			n = (n >> 1);
//			n = n & (n - 1);
//			res = res + 1;
//		}

		return table[n & 255] + table[(n >> 8) & 255] + table[(n >> 16) & 255] + table[(n >> 24)];
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 13;
		int count = countSet(n);
		System.out.println(count);

	}

}
