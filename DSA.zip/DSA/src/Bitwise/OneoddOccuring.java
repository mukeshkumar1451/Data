package Bitwise;

public class OneoddOccuring {

	private static int oddoccur(int[] arr, int len) {
		// TODO Auto-generated method stub
		// method1
//		for (int i = 0; i < len; i++) {
//			int count = 0;
//			for (int j = 0; j < len; j++) {
//				if (arr[i] == arr[j]) {
//					count++;
//				}
//			}
//			if (count % 2 != 0) {
//				return arr[i];
//			}
//
//		}
//		return 0;

		int res = arr[0];
		for (int i = 1; i < len; i++) {
			res = res ^ arr[i];
		}
		return res;

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 7, 3, 5, 7, 7, 5, 7 };
		int len = arr.length;

		int countdigit = oddoccur(arr, len);
		System.out.println(countdigit);

	}

}
