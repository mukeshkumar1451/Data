package Bitwise;

public class RightShift {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int x = 13;
		System.out.println(x >> 1);
		System.out.println(x >>> 1);
	}

}
