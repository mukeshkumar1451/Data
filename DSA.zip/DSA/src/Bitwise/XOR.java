package Bitwise;

public class XOR {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 3;
		int y = 6;
		System.out.println(x ^ y);

	}

}

//output
//1 1 -0
//0 0 -0
//1 0 -1
//0 1 -1

// 8 4 2 1
// 0 0 1 1
// 0 1 1 0
// 0 1 0 1-output