package Bitwise;

public class NOT {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int x = 5;
		System.out.println(~x);

	}

}

//output

//   8 4 2 1
// x-0 0 0 1
//~x-1 1 1 0
