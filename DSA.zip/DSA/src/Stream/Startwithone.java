package Stream;

import java.util.Arrays;
import java.util.List;

public class Startwithone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> s = Arrays.asList(12, 13, 15, 27, 19, null);

		s.stream().filter(i -> i != null && String.valueOf(i).startsWith("1"))

				.forEach(System.out::println);

	}

}
