package Stream;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SorttwoList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> s = Arrays.asList(1, 3, 5, 7, 9);
		List<Integer> p = Arrays.asList(0, 2, 4, 6, 8);

		Stream<Integer> st = Stream.concat(s.stream(), p.stream());
		List<Integer> out = st.sorted().collect(Collectors.toList());
		System.out.println(out);
	}

}
