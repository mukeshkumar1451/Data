package Stream;

import java.util.Arrays;

public class RemoveDuplicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 10, 12, 12, 19 };

		// int dup[] = Arrays.stream(arr).distinct().toArray();
		Arrays.stream(arr).distinct().forEach(System.out::println);

		// System.out.println(Arrays.toString(dup));

	}

}
