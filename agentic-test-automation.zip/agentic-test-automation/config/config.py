import os
from dotenv import load_dotenv

class Config:
    """
    Loads and exposes environment variables for the entire project.
    This class ensures all secrets and keys come from .env.
    """

    def __init__(self):
        # Load .env file
        load_dotenv()

        # MongoDB
        self.MONGO_URI = os.getenv("MONGO_URI")
        self.MONGO_DB = os.getenv("MONGO_DB")
        self.MONGO_COLLECTION = os.getenv("MONGO_COLLECTION", "testcases")

        # LLM: DeepSeek / Azure OpenAI
        self.DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY")

        self.AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
        self.AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
        self.AZURE_OPENAI_DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT")

        # LangFuse
        self.LANGFUSE_PUBLIC_KEY = os.getenv("LANGFUSE_PUBLIC_KEY")
        self.LANGFUSE_SECRET_KEY = os.getenv("LANGFUSE_SECRET_KEY")
        self.LANGFUSE_HOST = os.getenv("LANGFUSE_HOST")

    def validate(self):
        """
        Validate required configuration.
        Raise errors early before the workflow starts.
        """
        if not self.MONGO_URI:
            raise ValueError("Missing MONGO_URI in .env")

        if not self.MONGO_DB:
            raise ValueError("Missing MONGO_DB in .env")

        if not (
            self.DEEPSEEK_API_KEY
            or (self.AZURE_OPENAI_API_KEY and self.AZURE_OPENAI_ENDPOINT)
        ):
            raise ValueError("No LLM credentials provided. Configure DeepSeek or Azure OpenAI.")

        return True


# Singleton instance to use across project
config = Config()
