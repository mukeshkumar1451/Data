from pymongo import MongoClient
from config.config import config
from observability.langfuse_client import langfuse


class MongoClientWrapper:
    """
    MongoDB client wrapper used to fetch testcases
    based on module name (e.g., 'login', 'checkout').
    """

    def __init__(self):
        # Connect to MongoDB using config values
        self.client = MongoClient(config.MONGO_URI)
        self.db = self.client[config.MONGO_DB]
        self.collection = self.db[config.MONGO_COLLECTION]

    def get_testcases(self, module: str):
        """
        Return all testcases for a given module name.
        
        Mongo DB Document Format:
        {
            "module": "login",
            "title": "...",
            "steps": [...],
            ...
        }
        """
        query = {"module": module.lower().strip()}

        results = list(self.collection.find(query, {"_id": 0}))  # remove _id

        return results

    def get_all_modules(self):
        """
        Return list of distinct module names in the collection.
        """
        return self.collection.distinct("module")
    
    

def load_testcases(module_name):
    trace = langfuse.trace(name="mongodb_load_testcases")
    
    try:
        span = trace.span("mongodb_query")
        data = list(collection.find({"module": module_name}))
        span.end()

        trace.update(output=f"Loaded {len(data)} testcases")
        trace.end()
        return data

    except Exception as e:
        trace.update(error=str(e))
        trace.end()
        raise e



# Singleton instance for reuse
mongo = MongoClientWrapper()
