import os
from langchain.chat_models import ChatOpenAI
from langchain.schema import HumanMessage
from config.config import config
from observability.langfuse_client import langfuse


class LLMClient:
    """
    Wrapper for the DeepSeek LLM using LangChain.
    Compatible with LangGraph agent nodes.
    """

    def __init__(self):
        """
        Initialize ChatOpenAI using DeepSeek API.
        Note:
        DeepSeek uses 'openai-compatible' API.
        """
        if not config.DEEPSEEK_API_KEY:
            raise Exception("DeepSeek API key not found in .env")

        self.model = ChatOpenAI(
            model="deepseek-chat",
            api_key=config.DEEPSEEK_API_KEY,
            base_url="https://api.deepseek.com",
            temperature=0.1
        )

    def generate(self, prompt: str) -> str:
        """
        Generate text output using DeepSeek LLM.
        """
        try:
            response = self.model([HumanMessage(content=prompt)])
            return response.content
        except Exception as e:
            print("LLM Error:", e)
            return "LLM_ERROR"

    def generate_code(self, testcase: dict, framework: str = "playwright") -> str:
        """
        Convert a JSON testcase into a TypeScript test script.
        """
        prompt = f"""
        Convert this testcase into a valid Playwright TypeScript test (.spec.ts):

        Testcase:
        {testcase}

        Rules:
        - Use Playwright test format
        - Use 'test()' from '@playwright/test'
        - Generate clean readable TypeScript
        - Do NOT include explanations, only code
        """

        return self.generate(prompt)
    
    

def ask_llm(prompt: str):
    trace = langfuse.trace(name="generate_test_script")

    try:
        span = trace.span(name="llm_request")
        result = llm.invoke(prompt)
        span.end()
        
        trace.update(output=result)
        trace.end()
        return result

    except Exception as e:
        trace.update(error=str(e))
        trace.end()
        raise e



# Singleton instance
llm = LLMClient()
