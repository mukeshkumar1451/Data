package com.intro;

public class Book {

	int noOfCoppies;

	void Language() {
		System.out.println("Awsome PL");
	}

}
