package com.intro;

public class MotorBikeRunner {
	public static void main(String[] args) {

		MotorBike Pulsar = new MotorBike();
		MotorBike Honda = new MotorBike();

		Pulsar.start();
		Honda.start();

		Pulsar.setSpeed(80);
		Honda.setSpeed(0);

		System.out.println(Pulsar.getSpeed());
		System.out.println(Honda.getSpeed());

	}

}
