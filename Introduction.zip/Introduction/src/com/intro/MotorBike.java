package com.intro;

public class MotorBike {

	private int Speed;

	public int getSpeed() {
		return Speed;
	}

	public void setSpeed(int speed) {
		Speed = speed;
	}

	public MotorBike(int speed) {
		super();
		Speed = speed;
	}

	public MotorBike() {
		// TODO Auto-generated constructor stub
	}

	void start() {
		System.out.println("Bike started");
	}
}
