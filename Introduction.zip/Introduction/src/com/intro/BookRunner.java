package com.intro;

public class BookRunner {

	public static void main(String[] args) {
		Book artofProgrammingLanguage = new Book();
		Book EffectiveJava = new Book();
		Book CleanCode = new Book();

		artofProgrammingLanguage.Language();
		EffectiveJava.Language();
		CleanCode.Language();

		artofProgrammingLanguage.noOfCoppies = 100;
		EffectiveJava.noOfCoppies = 60;
		CleanCode.noOfCoppies = 50;

	}

}
