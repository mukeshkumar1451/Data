package com.learn;

public class ProductArray {

	public int[] productExceptSelfOptimized(int[] nums) {
		int n = nums.length;
		int[] result = new int[n];

		// Step 1: Compute prefix products and store in result[]
		result[0] = 1;
		for (int i = 1; i < n; i++) {
			result[i] = result[i - 1] * nums[i - 1];
		}

		// Step 2: Compute suffix products and multiply with result[]
		int suffixProduct = 1;
		for (int i = n - 1; i >= 0; i--) {
			result[i] *= suffixProduct;
			suffixProduct *= nums[i];
		}

		return result;
	}

	public static void main(String[] args) {
		ProductArray pa = new ProductArray();
		int[] nums = { 1, 2, 3, 4 };
		int[] result = pa.productExceptSelfOptimized(nums);

		System.out.print("Optimized Output: ");
		for (int val : result) {
			System.out.print(val + " ");
		}
	}
}
