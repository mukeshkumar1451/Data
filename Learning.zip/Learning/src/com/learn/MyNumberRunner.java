package com.learn;

public class MyNumberRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyNumber number = new MyNumber(5);
		boolean isPrime = number.isPrime();
		System.out.println("isprime " + isPrime);

		number.triangle();
		// System.out.println("triangle " + triangle);
		number.leftTriangle();

		number.drilTriangle();

		number.lowerTriangle();

		number.kTriangle();
		number.incTriangle();
		number.columnTriangle();
		number.reverseTriangle();

	}

}
