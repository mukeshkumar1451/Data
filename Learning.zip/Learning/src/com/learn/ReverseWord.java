package com.learn;

public class ReverseWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "Hello world";
		StringBuilder str = new StringBuilder();

		String[] words = s.split(" ");

		for (int i = words.length - 1; i >= 0; i--) {
			str.append(words[i]).append(" ");
		}

		System.out.println(str.toString());
	}

}
