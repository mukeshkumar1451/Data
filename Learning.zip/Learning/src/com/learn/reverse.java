package com.learn;

import java.util.Arrays;
import java.util.stream.Collectors;

public class reverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "i am mukesh";
		StringBuilder str = new StringBuilder(s);

		String[] words = s.split(" ");

		String reverse = Arrays.stream(words).map(word -> new StringBuilder(word).reverse().toString())
				.collect(Collectors.joining(" "));

		System.out.println(reverse);

	}

}
