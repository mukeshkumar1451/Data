package com.learn;

public class MyNumber {

	private int number;

	public MyNumber(int number) {
		// TODO Auto-generated constructor stub
		this.number = number;
	}

	public boolean isPrime() {
		// TODO Auto-generated method stub
		for (int i = 2; i <= number - 1; i++) {
			if (number % i == 0) {
				return false;
			}
		}
		return true;
	}

	public void triangle() {
		// TODO Auto-generated method stub
		for (int i = 1; i <= number; i++) {
			System.out.println();
			for (int j = 1; j <= i; j++) {

				System.out.print(j + " ");
			}

		}

	}

	public void leftTriangle() {
		// TODO Auto-generated method stub
		System.out.println("\n");
		for (int i = 1; i <= number; i++) {

			for (int j = 2 * (number - i); j >= 1; j--) {
				System.out.print(" ");
			}

			for (int j = 1; j <= i; j++) {
				System.out.print(j + " ");
			}
			System.out.println();
		}

	}

	public void drilTriangle() {
		// TODO Auto-generated method stub
		System.out.println("\n");

		for (int i = 1; i <= number; i++) {
			for (int j = 1; j <= i; j++) {
				System.out.print(j + " ");
			}
			System.out.println();
		}
		for (int i = number - 1; i >= 1; i--) {
			for (int j = 1; j <= i; j++) {
				System.out.print(j + " ");
			}
			System.out.println();

		}
	}

	public void lowerTriangle() {
		// TODO Auto-generated method stub
		System.out.println("\n");
		for (int i = number; i >= 1; i--) {
			for (int j = i; j >= 1; j--) {
				System.out.print(j + " ");
			}
			System.out.println();
		}

	}

	public void kTriangle() {
		// TODO Auto-generated method stub
		System.out.println("\n");
		for (int i = number; i >= 1; i--) {
			for (int j = 1; j <= i; j++) {
				System.out.print(j + " ");
			}
			System.out.println();

		}
		for (int i = 2; i <= number; i++) {
			for (int j = 1; j <= i; j++) {
				System.out.print(j + " ");
			}
			System.out.println();

		}

	}

	public void incTriangle() {
		// TODO Auto-generated method stub
		System.out.println("\n");
		int counter = 1;
		for (int i = 1; i <= number; i++) {
			for (int j = 1; j <= i; j++) {
				System.out.print(counter + " ");
				counter++;

			}
			System.out.println();

		}

	}

	public void columnTriangle() {
		// TODO Auto-generated method stub
		System.out.println("\n");

		for (int i = 1; i <= number; i++) {
			int counter = i;

			for (int j = 1; j <= i; j++) {

				System.out.print(counter + " ");
				// counter++;
				counter = counter + number - j;

			}
			System.out.println();

		}

	}

	public void reverseTriangle() {
		// TODO Auto-generated method stub
		System.out.println("\n");

		for (int i = 1; i <= number; i++) {

			for (int j = 1; j <= i; j++) {

				System.out.print(j + " ");

			}
			for (int k = i - 1; k >= 1; k--) {
				System.out.print(k + " ");
			}
			System.out.println();

		}

	}

}
