package com.learn;

public class Fibbnice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n = 10;
		for (int i = 0; i <= n; i++) {
			System.out.println(fib(i));
		}
	}

	private static int fib(int n) {
		// TODO Auto-generated method stub
		if (n <= 1) {
			return n;
		}
		return fib(n - 1) + fib(n - 2);
	}

}
