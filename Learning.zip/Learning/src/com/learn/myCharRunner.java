package com.learn;

public class myCharRunner {

	public static void main(String[] args) {

		MyChar myChar = new MyChar('6');
		System.out.println(myChar.isVowel());

		System.out.println(myChar.isNumber());
		System.out.println(myChar.isAlphabet());

	}

}
