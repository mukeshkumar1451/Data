package com.learn;

public class ArrayLeaders {

	public void printLeadersOriginalOrder(int[] arr) {
		printLeadersRecursive(arr, arr.length - 1, Integer.MIN_VALUE);
	}

	private void printLeadersRecursive(int[] arr, int index, int maxSoFar) {
		if (index < 0) {
			return;
		}

		// Recursive call first
		printLeadersRecursive(arr, index - 1, Math.max(maxSoFar, arr[index]));

		// Print after recursion to maintain original order
		if (arr[index] > maxSoFar) {
			System.out.print(arr[index] + " ");
		}
	}

	public static void main(String[] args) {
		int[] arr = { 16, 17, 4, 3, 5, 2 };
		new ArrayLeaders().printLeadersOriginalOrder(arr);

	}
}
