package com.learn;

public class NumberSeries {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 5;
		// char ch = 'A';

		for (char i = 'A'; i <= 'E'; i++) {
			for (char j = 'A'; j <= i; j++) {
				System.out.print(i + " ");
			}
			System.out.println();
		}
	}
}
