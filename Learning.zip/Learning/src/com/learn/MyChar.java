package com.learn;

public class MyChar {

	private char ch;

	public MyChar(char ch) {
		// TODO Auto-generated constructor stub
		this.ch = ch;
	}

	public boolean isVowel() {
		// TODO Auto-generated method stub
		if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
			return true;
		} else {
			return false;
		}
	}

	public boolean isNumber() {
		// TODO Auto-generated method stub
		if (ch >= 48 && ch <= 57) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isAlphabet() {
		// TODO Auto-generated method stub
		if (ch >= 97 && ch <= 122 || ch >= 65 && ch <= 90) {
			return true;
		} else {
			return false;
		}
	}

}
