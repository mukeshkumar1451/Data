package com.learn;

public class Muliplicationtable {

	void Mtable() {
		for (int i = 1; i <= 10; i++) {
			System.out.printf("%d * %d=%d", 5, i, 5 * i).println();
			System.out.println();
		}
	}

	public static void main(String[] args) {

	}

}
