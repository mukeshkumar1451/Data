package com.learn;

public class sumofdigit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int number = 234;
		System.out.println("totalsum value" + sumofnumber(number));
	}

	public static int sumofnumber(int number) {
		// TODO Auto-generated method stub
		int rev = 0;
		while (number > 0) {
			int num = number % 10;
			System.out.println("num value" + num);
			rev = rev * 10 + num;
			System.out.println("sum value" + rev);
			number /= 10;
			System.out.println("number value" + number);

		}
		return rev;

	}

}
