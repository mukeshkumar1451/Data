package com.learn;

public class CharacterCount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "Mukesh Kumar";
		s = s.toLowerCase().replaceAll("[^a-z]", "");

		while (s.length() > 0) {
			char current = s.charAt(0);
			int count = 0;

			for (int i = 0; i < s.length(); i++) {
				if (s.charAt(i) == current) {
					count++;
				}
			}
			System.out.println(current + " " + count);
			s = s.replace(String.valueOf(current), "");

		}

	}

}
