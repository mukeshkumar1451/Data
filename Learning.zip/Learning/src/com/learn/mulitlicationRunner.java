package com.learn;

public class mulitlicationRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Muliplicationtable table=new Muliplicationtable();
		table.Mtable();
	}

}
