package com.learn;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class ZephyrScaleAPI {
	public static void main(String[] args) {
		try {
			// Define the search endpoint URL with query parameters
			String searchUrl = "https://app.tm4j.smartbear.com/backend/rest/tests/2.0/testcase/search?fields=id,key,projectId,name,averageTime,estimatedTime,labels,folderId,componentId,status(id,name,i18nKey,color),priority(id,name,i18nKey,color),lastTestResultStatus(name,i18nKey,color),majorVersion,createdOn,createdBy,updatedOn,updatedBy,customFieldValues,owner,folderId&query=testCase.projectId+IN+(10001)+ORDER+BY+testCase.lastTestResultStatusIndex+ASC&startAt=0&maxResults=40&archived=false";

			// Set up the headers with your access token
			String accessToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI3MTIwMjA6MzJiZGFhYmQtMjViMS00NjUyLWFhNGMtNGNhNThlYzViOTBjIiwicXNoIjoiY29udGV4dC1xc2giLCJpc3MiOiIxNzQ5MjgwMC01NWE0LTMyMmEtYjZhOC02NTNkYjJjOTBkYWUiLCJjb250ZXh0Ijp7ImxpY2Vuc2UiOnsiYWN0aXZlIjp0cnVlLCJjYXBhYmlsaXR5U2V0IjoiY2FwYWJpbGl0eVN0YW5kYXJkIn0sInVybCI6eyJkaXNwbGF5VXJsIjoiaHR0cHM6XC9cL3VzZXJzYW1wbGUzOTIuYXRsYXNzaWFuLm5ldCIsImRpc3BsYXlVcmxTZXJ2aWNlZGVza0hlbHBDZW50ZXIiOiJodHRwczpcL1wvdXNlcnNhbXBsZTM5Mi5hdGxhc3NpYW4ubmV0In0sImppcmEiOnsicHJvamVjdCI6eyJrZXkiOiJBTSIsImlkIjoiMTAwMDEifX19LCJleHAiOjE3NDExNTg1NTIsImlhdCI6MTc0MTE1NzY1Mn0.3x4L1dToIbCydj_3s76Yo7hs386Z3ELX3sSoytmYtjk";

			// Create a URL object
			URL url = new URL(searchUrl);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Authorization", "Bearer " + accessToken);
			conn.setRequestProperty("Accept", "application/json");

			// Read the response
			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				try (Scanner scanner = new Scanner(conn.getInputStream(), "UTF-8")) {
					String responseBody = scanner.useDelimiter("\\A").next();
					System.out.println(responseBody);
				}
			} else {
				System.out.println("Failed to search test cases: " + responseCode);
			}

			conn.disconnect();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
