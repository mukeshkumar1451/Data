package com.learn;

public class Hello {

	public static void main(String[] args) {
		int n = 79685;

//		while (n > 0) {
//			if (n % 3 == 2) {
//				System.out.println("false");
//			}
//			n /= 3;
//		}
//		System.out.println("true");
		System.out.println(5 % 2);
		System.out.println(0 / 3);

		System.out.println(69674L * 69675);
		int result = (n - 1) * n;
		System.out.println(result);
		System.out.println(1L + 2L * (n - 1) * n);

		System.out.println(1 + 2 * (n - 1) * n);
	}

}
