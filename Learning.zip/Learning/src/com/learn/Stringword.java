package com.learn;

public class Stringword {

	public static boolean main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "Hello";
		String s2 = "Hello";

		StringBuilder s = new StringBuilder(s1);
		StringBuilder sa = new StringBuilder(s2);

		if (s1.equals(s2)) {
			return true;
		} else {
			return false;
		}

//		if(s1==s2) {
//			return true;
//		} else {
//			return false;
//		}

	}

}
