package com.learn;

public class WaterTapping {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 0, 1, 0, 2, 1, 0, 1, 3, 2, 1, 2, };
		int n = arr.length;

		int result = rainwater(arr, n);
		System.out.println(result);

	}

	private static int rainwater(int[] arr, int n) {
		// TODO Auto-generated method stub

		int ans = 0;
		int l = 0, r = n - 1;
		int lmax = 0, rmax = 0;

		while (l < r) {
			lmax = Math.max(lmax, arr[l]);
			rmax = Math.max(rmax, arr[r]);

			if (lmax < rmax) {
				ans = ans + (lmax - arr[l]);
				l++;
			} else {
				ans += (rmax - arr[r]);
				r--;
			}
		}
		return ans;
	}

}
