package loanapp;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 5;
		int res = n % 2;
		System.out.println(res);

	}

}
