package loanapp;

public class LoanValidation {
	public static boolean verifyLoanAmount(int loanAmount) {

		if (loanAmount < 500000) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean verifyTenure(int tenure) {
		if (tenure == 3 || tenure == 6 || tenure == 9 || tenure == 12) {
			return true;
		} else {
			return false;
		}

	}

}
