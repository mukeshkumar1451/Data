package loanapp;

import java.util.Scanner;

public class LoanMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("Enter your loan Amount");
		int loanAmount = s.nextInt();
		System.out.println("Enter your emi Month " + "PLease enter in 3 or 6 or 9 or 12");
		int tenure = s.nextInt();
		Loan l1 = new Loan();
		l1.ShowEmiDetails(loanAmount, tenure);

	}

}
