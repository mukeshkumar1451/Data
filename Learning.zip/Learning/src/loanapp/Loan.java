package loanapp;

public class Loan {
	private int loanAmount;
	private static double interestRate = 7.5;
	private int tenure;

	public void validation(int loanAmount, int tenure) {
		if (LoanValidation.verifyLoanAmount(loanAmount)) {
			this.loanAmount = loanAmount;
		} else {
			System.err.println("Invalid LoanAmount");
		}
		if (LoanValidation.verifyTenure(tenure)) {
			this.tenure = tenure;
		} else {
			System.err.println("Invalid tenure");
		}
	}

	public void ShowEmiDetails(int loanAmount, int tenure) {
		double monthly = interestRate / 12 / 100;
		double emi = (loanAmount * monthly * Math.pow(1 + monthly, tenure)) / (Math.pow(1 + monthly, tenure) - 1);
		for (int i = 1; i <= tenure; i++) {

			System.out.println("the emi:" + i + "" + ":" + Math.round(emi));
		}

	}
}
