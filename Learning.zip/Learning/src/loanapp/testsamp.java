package loanapp;

public class testsamp {

	private String name;
	private String lastname;
	private int id;

}
